var networks = {"mTOR56_reg.xgmml": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.1",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "mTOR56_reg.xgmml",
    "name" : "mTOR56_reg.xgmml",
    "SUID" : 1012,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "157",
        "shared_name" : "[Output]",
        "name" : "[Output]",
        "SUID" : 157,
        "rxnconID" : "[Output]",
        "type" : "output",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -1285.7043218944682,
        "y" : 51.00014114379883
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "156",
        "shared_name" : "eIF4E_[A001]_ppi-_eIF4G_[A002]",
        "name" : "eIF4E_[A001]_ppi-_eIF4G_[A002]",
        "SUID" : 156,
        "rxnconID" : "eIF4E_[A001]_ppi-_eIF4G_[A002]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -977.0320434570312,
        "y" : 403.1924928620599
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "155",
        "shared_name" : "[eIF4G]",
        "name" : "[eIF4G]",
        "SUID" : 155,
        "rxnconID" : "[eIF4G]",
        "type" : "input",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -950.310791015625,
        "y" : -13.554645538330078
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "154",
        "shared_name" : "eIF4E_[A001]--eIF4G_[A002]",
        "name" : "eIF4E_[A001]--eIF4G_[A002]",
        "SUID" : 154,
        "rxnconID" : "eIF4E_[A001]--eIF4G_[A002]",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -1082.9181398347162,
        "y" : 175.6685698531497
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "153",
        "shared_name" : "eIF4E_[A001]_ppi+_eIF4G_[A002]",
        "name" : "eIF4E_[A001]_ppi+_eIF4G_[A002]",
        "SUID" : 153,
        "rxnconID" : "eIF4E_[A001]_ppi+_eIF4G_[A002]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -855.9663818825071,
        "y" : 149.2432861328125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "152",
        "shared_name" : "PPM1G_p-_EIF4EBP1_[(Thr70)]",
        "name" : "PPM1G_p-_EIF4EBP1_[(Thr70)]",
        "SUID" : 152,
        "rxnconID" : "PPM1G_p-_EIF4EBP1_[(Thr70)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 595.258362818005,
        "y" : -112.43304535105612
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "151",
        "shared_name" : "PPM1G_p-_EIF4EBP1_[(Ser65)]",
        "name" : "PPM1G_p-_EIF4EBP1_[(Ser65)]",
        "SUID" : 151,
        "rxnconID" : "PPM1G_p-_EIF4EBP1_[(Ser65)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 319.5780063304941,
        "y" : -305.70107556113646
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "150",
        "shared_name" : "PPM1G_p-_EIF4EBP1_[(Thr46)]",
        "name" : "PPM1G_p-_EIF4EBP1_[(Thr46)]",
        "SUID" : 150,
        "rxnconID" : "PPM1G_p-_EIF4EBP1_[(Thr46)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 488.75056827124206,
        "y" : 119.54462568893591
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "149",
        "shared_name" : "PPM1G_p-_EIF4EBP1_[(Thr37)]",
        "name" : "PPM1G_p-_EIF4EBP1_[(Thr37)]",
        "SUID" : 149,
        "rxnconID" : "PPM1G_p-_EIF4EBP1_[(Thr37)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 809.5575109866888,
        "y" : 235.321533203125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "148",
        "shared_name" : "mTORC1_p+_EIF4EBP1_[(Thr70)]",
        "name" : "mTORC1_p+_EIF4EBP1_[(Thr70)]",
        "SUID" : 148,
        "rxnconID" : "mTORC1_p+_EIF4EBP1_[(Thr70)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 181.78638712234994,
        "y" : 102.29405212402344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "147",
        "shared_name" : "mTORC1_p+_EIF4EBP1_[(Ser65)]",
        "name" : "mTORC1_p+_EIF4EBP1_[(Ser65)]",
        "SUID" : 147,
        "rxnconID" : "mTORC1_p+_EIF4EBP1_[(Ser65)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -43.13628005981445,
        "y" : -3.7096700640113536
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "146",
        "shared_name" : "mTORC1_p+_EIF4EBP1_[(Thr46)]",
        "name" : "mTORC1_p+_EIF4EBP1_[(Thr46)]",
        "SUID" : 146,
        "rxnconID" : "mTORC1_p+_EIF4EBP1_[(Thr46)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -49.36888885498047,
        "y" : 342.99603271484375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "145",
        "shared_name" : "mTORC1",
        "name" : "mTORC1",
        "SUID" : 145,
        "rxnconID" : "mTORC1",
        "type" : "boolean_and",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 94.02567487666194,
        "y" : 426.9508972167969
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "144",
        "shared_name" : "mTORC1_p+_EIF4EBP1_[(Thr37)]",
        "name" : "mTORC1_p+_EIF4EBP1_[(Thr37)]",
        "SUID" : 144,
        "rxnconID" : "mTORC1_p+_EIF4EBP1_[(Thr37)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 194.0604705810547,
        "y" : 344.4555358886719
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "143",
        "shared_name" : "eIF4E_[A001]_ppi-_EIF4EBP1_[A001]",
        "name" : "eIF4E_[A001]_ppi-_EIF4EBP1_[A001]",
        "SUID" : 143,
        "rxnconID" : "eIF4E_[A001]_ppi-_EIF4EBP1_[A001]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -654.6984985817259,
        "y" : 388.8582150991829
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "142",
        "shared_name" : "EIF4EBP1_[(Thr70)]-{p}",
        "name" : "EIF4EBP1_[(Thr70)]-{p}",
        "SUID" : 142,
        "rxnconID" : "EIF4EBP1_[(Thr70)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 190.2307586669922,
        "y" : -4.213766574859619
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "141",
        "shared_name" : "EIF4EBP1_[(Ser65)]-{p}",
        "name" : "EIF4EBP1_[(Ser65)]-{p}",
        "SUID" : 141,
        "rxnconID" : "EIF4EBP1_[(Ser65)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -47.95740509033203,
        "y" : -146.80384540840078
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "140",
        "shared_name" : "EIF4EBP1_[(Thr37)]-{p}",
        "name" : "EIF4EBP1_[(Thr37)]-{p}",
        "SUID" : 140,
        "rxnconID" : "EIF4EBP1_[(Thr37)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 189.25438944168587,
        "y" : 264.02349853515625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "139",
        "shared_name" : "EIF4EBP1_[(Thr46)]-{p}",
        "name" : "EIF4EBP1_[(Thr46)]-{p}",
        "SUID" : 139,
        "rxnconID" : "EIF4EBP1_[(Thr46)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -59.168357849121094,
        "y" : 249.93710327148438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "138",
        "shared_name" : "translation",
        "name" : "translation",
        "SUID" : 138,
        "rxnconID" : "translation",
        "type" : "boolean_and",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -487.135009765625,
        "y" : -89.8887939453125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "137",
        "shared_name" : "[eIF4E]",
        "name" : "[eIF4E]",
        "SUID" : 137,
        "rxnconID" : "[eIF4E]",
        "type" : "input",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -801.0585569891973,
        "y" : 483.8342590332031
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "136",
        "shared_name" : "[EIF4EBP1]",
        "name" : "[EIF4EBP1]",
        "SUID" : 136,
        "rxnconID" : "[EIF4EBP1]",
        "type" : "input",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -298.27886962890625,
        "y" : 562.059802199524
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "135",
        "shared_name" : "EIF4EBP1_[A001]--eIF4E_[A001]",
        "name" : "EIF4EBP1_[A001]--eIF4E_[A001]",
        "SUID" : 135,
        "rxnconID" : "EIF4EBP1_[A001]--eIF4E_[A001]",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -713.5267021658251,
        "y" : 248.49649047851562
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "134",
        "shared_name" : "eIF4E_[A001]_ppi+_EIF4EBP1_[A001]",
        "name" : "eIF4E_[A001]_ppi+_EIF4EBP1_[A001]",
        "SUID" : 134,
        "rxnconID" : "eIF4E_[A001]_ppi+_EIF4EBP1_[A001]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -330.5656966639759,
        "y" : 412.53538523650127
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "133",
        "shared_name" : "[mTOR]",
        "name" : "[mTOR]",
        "SUID" : 133,
        "rxnconID" : "[mTOR]",
        "type" : "input",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 53.581122372164444,
        "y" : 660.515823724296
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "132",
        "shared_name" : "[Raptor]",
        "name" : "[Raptor]",
        "SUID" : 132,
        "rxnconID" : "[Raptor]",
        "type" : "input",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -102.43932574510374,
        "y" : 656.706133301256
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "131",
        "shared_name" : "Raptor_[mTOR]--mTOR_[Raptor]",
        "name" : "Raptor_[mTOR]--mTOR_[Raptor]",
        "SUID" : 131,
        "rxnconID" : "Raptor_[mTOR]--mTOR_[Raptor]",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -32.59690192571826,
        "y" : 476.8858642578125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "130",
        "shared_name" : "mTOR_[Raptor]_ppi+_Raptor_[mTOR]",
        "name" : "mTOR_[Raptor]_ppi+_Raptor_[mTOR]",
        "SUID" : 130,
        "rxnconID" : "mTOR_[Raptor]_ppi+_Raptor_[mTOR]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : -30.46670729381931,
        "y" : 576.2553100585938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "582",
        "shared_name" : "RHEB_[switch1DSYDPTIEN]_ppi-_mTOR_[FATfα2fα3]",
        "name" : "RHEB_[switch1DSYDPTIEN]_ppi-_mTOR_[FATfα2fα3]",
        "SUID" : 582,
        "rxnconID" : "RHEB_[switch1DSYDPTIEN]_ppi-_mTOR_[FATfα2fα3]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 150.64450073242188,
        "y" : 773.1250971217097
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "583",
        "shared_name" : "RHEB_[switch1DSYDPTIEN]--mTOR_[FATfα2fα3]",
        "name" : "RHEB_[switch1DSYDPTIEN]--mTOR_[FATfα2fα3]",
        "SUID" : 583,
        "rxnconID" : "RHEB_[switch1DSYDPTIEN]--mTOR_[FATfα2fα3]",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 319.85560801345423,
        "y" : 631.7381591796875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "584",
        "shared_name" : "RHEB_[switch1DSYDPTIEN]_ppi+_mTOR_[FATfα2fα3]",
        "name" : "RHEB_[switch1DSYDPTIEN]_ppi+_mTOR_[FATfα2fα3]",
        "SUID" : 584,
        "rxnconID" : "RHEB_[switch1DSYDPTIEN]_ppi+_mTOR_[FATfα2fα3]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 334.236249896702,
        "y" : 885.6077880859375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "585",
        "shared_name" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi-_mTOR_[Nheatnα3tonα7]",
        "name" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi-_mTOR_[Nheatnα3tonα7]",
        "SUID" : 585,
        "rxnconID" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi-_mTOR_[Nheatnα3tonα7]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1442.8564839796784,
        "y" : 541.1512717660603
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "586",
        "shared_name" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]--mTOR_[Nheatnα3tonα7]",
        "name" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]--mTOR_[Nheatnα3tonα7]",
        "SUID" : 586,
        "rxnconID" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]--mTOR_[Nheatnα3tonα7]",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1398.9969215933147,
        "y" : 688.4475574763449
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "587",
        "shared_name" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi+_mTOR_[Nheatnα3tonα7]",
        "name" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi+_mTOR_[Nheatnα3tonα7]",
        "SUID" : 587,
        "rxnconID" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi+_mTOR_[Nheatnα3tonα7]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1412.701416015625,
        "y" : 934.8001708984375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "588",
        "shared_name" : "RHEB_[switch1]_ppi-_mTOR_[Mheatmα2mα3mα4]",
        "name" : "RHEB_[switch1]_ppi-_mTOR_[Mheatmα2mα3mα4]",
        "SUID" : 588,
        "rxnconID" : "RHEB_[switch1]_ppi-_mTOR_[Mheatmα2mα3mα4]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 590.5650098671838,
        "y" : 443.4525528632825
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "589",
        "shared_name" : "RHEB_[switch1]--mTOR_[Mheatmα2mα3mα4]",
        "name" : "RHEB_[switch1]--mTOR_[Mheatmα2mα3mα4]",
        "SUID" : 589,
        "rxnconID" : "RHEB_[switch1]--mTOR_[Mheatmα2mα3mα4]",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 640.2288818359375,
        "y" : 629.7636108398438
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "590",
        "shared_name" : "RHEB_[switch1]_ppi+_mTOR_[Mheatmα2mα3mα4]",
        "name" : "RHEB_[switch1]_ppi+_mTOR_[Mheatmα2mα3mα4]",
        "SUID" : 590,
        "rxnconID" : "RHEB_[switch1]_ppi+_mTOR_[Mheatmα2mα3mα4]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 785.1140747070312,
        "y" : 883.6163712226576
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "120",
        "shared_name" : "TSC2_gap_RHEB_[(G)]",
        "name" : "TSC2_gap_RHEB_[(G)]",
        "SUID" : 120,
        "rxnconID" : "TSC2_gap_RHEB_[(G)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 816.7009874993254,
        "y" : 1186.3963610344817
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "119",
        "shared_name" : "RHEB_[(G)]-{gtp}",
        "name" : "RHEB_[(G)]-{gtp}",
        "SUID" : 119,
        "rxnconID" : "RHEB_[(G)]-{gtp}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 820.5787478903867,
        "y" : 1084.028564453125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "118",
        "shared_name" : "GTP_gef_RHEB_[(G)]",
        "name" : "GTP_gef_RHEB_[(G)]",
        "SUID" : 118,
        "rxnconID" : "GTP_gef_RHEB_[(G)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1347.404345371332,
        "y" : 1030.2327880859375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "117",
        "shared_name" : "TSC1_[Cterminus]_ppi-_TSC2_[Nterminus]",
        "name" : "TSC1_[Cterminus]_ppi-_TSC2_[Nterminus]",
        "SUID" : 117,
        "rxnconID" : "TSC1_[Cterminus]_ppi-_TSC2_[Nterminus]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1036.066162109375,
        "y" : 1124.11474609375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "116",
        "shared_name" : "destabilization",
        "name" : "destabilization",
        "SUID" : 116,
        "rxnconID" : "destabilization",
        "type" : "boolean_and",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1369.7812452299083,
        "y" : 1200.6063711162942
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "115",
        "shared_name" : "TSC1_[Cterminus]--TSC2_[Nterminus]",
        "name" : "TSC1_[Cterminus]--TSC2_[Nterminus]",
        "SUID" : 115,
        "rxnconID" : "TSC1_[Cterminus]--TSC2_[Nterminus]",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 817.3792975385859,
        "y" : 1281.8375729103946
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "114",
        "shared_name" : "TSC1_[Cterminus]_ppi+_TSC2_[Nterminus]",
        "name" : "TSC1_[Cterminus]_ppi+_TSC2_[Nterminus]",
        "SUID" : 114,
        "rxnconID" : "TSC1_[Cterminus]_ppi+_TSC2_[Nterminus]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 825.2159423828125,
        "y" : 1396.0039698764454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1028",
        "shared_name" : "PP5_p-_TSC2_[(Ser1130)]",
        "name" : "PP5_p-_TSC2_[(Ser1130)]",
        "SUID" : 1028,
        "rxnconID" : "PP5_p-_TSC2_[(Ser1130)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1772.143798828125,
        "y" : 1239.3816434084843
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1027",
        "shared_name" : "PP5_p-_TSC2_[(Ser981)]",
        "name" : "PP5_p-_TSC2_[(Ser981)]",
        "SUID" : 1027,
        "rxnconID" : "PP5_p-_TSC2_[(Ser981)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1532.7858370602655,
        "y" : 1154.260009765625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1026",
        "shared_name" : "PP5_p-_TSC2_[(Thr1462)]",
        "name" : "PP5_p-_TSC2_[(Thr1462)]",
        "SUID" : 1026,
        "rxnconID" : "PP5_p-_TSC2_[(Thr1462)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1799.463304389468,
        "y" : 1073.2354547857187
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1025",
        "shared_name" : "PP5_p-_TSC2_[(Ser939)]",
        "name" : "PP5_p-_TSC2_[(Ser939)]",
        "SUID" : 1025,
        "rxnconID" : "PP5_p-_TSC2_[(Ser939)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1072.0668617667343,
        "y" : 1454.6795465825937
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1024",
        "shared_name" : "unk_p-_PPM1G_[(AKT2)]",
        "name" : "unk_p-_PPM1G_[(AKT2)]",
        "SUID" : 1024,
        "rxnconID" : "unk_p-_PPM1G_[(AKT2)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 2200.8863222180157,
        "y" : -160.55664857222055
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "108",
        "shared_name" : "PPM1G_[(AKT2)]-{p}",
        "name" : "PPM1G_[(AKT2)]-{p}",
        "SUID" : 108,
        "rxnconID" : "PPM1G_[(AKT2)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1760.1342513699612,
        "y" : -127.98760452841186
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "107",
        "shared_name" : "AKT2_p+_PPM1G_[(AKT2)]",
        "name" : "AKT2_p+_PPM1G_[(AKT2)]",
        "SUID" : 107,
        "rxnconID" : "AKT2_p+_PPM1G_[(AKT2)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1875.614718659659,
        "y" : -26.908085862394312
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "106",
        "shared_name" : "TSC2_[(Ser1130)]-{p}",
        "name" : "TSC2_[(Ser1130)]-{p}",
        "SUID" : 106,
        "rxnconID" : "TSC2_[(Ser1130)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1689.8428955078125,
        "y" : 1338.85498046875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "105",
        "shared_name" : "AKT2_p+_TSC2_[(Ser1130)]",
        "name" : "AKT2_p+_TSC2_[(Ser1130)]",
        "SUID" : 105,
        "rxnconID" : "AKT2_p+_TSC2_[(Ser1130)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1757.73095703125,
        "y" : 1550.8973999394373
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "104",
        "shared_name" : "TSC2_[(Ser981)]-{p}",
        "name" : "TSC2_[(Ser981)]-{p}",
        "SUID" : 104,
        "rxnconID" : "TSC2_[(Ser981)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1367.4384765625,
        "y" : 1336.81884765625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "103",
        "shared_name" : "AKT2_p+_TSC2_[(Ser981)]",
        "name" : "AKT2_p+_TSC2_[(Ser981)]",
        "SUID" : 103,
        "rxnconID" : "AKT2_p+_TSC2_[(Ser981)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1383.292175255875,
        "y" : 1553.9361572265625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "102",
        "shared_name" : "TSC2_[(Thr1462)]-{p}",
        "name" : "TSC2_[(Thr1462)]-{p}",
        "SUID" : 102,
        "rxnconID" : "TSC2_[(Thr1462)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1533.4479289953026,
        "y" : 1336.7028278406349
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "101",
        "shared_name" : "AKT2_p+_TSC2_[(Thr1462)]",
        "name" : "AKT2_p+_TSC2_[(Thr1462)]",
        "SUID" : 101,
        "rxnconID" : "AKT2_p+_TSC2_[(Thr1462)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1566.73876953125,
        "y" : 1551.4658203125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "100",
        "shared_name" : "enhancedAKT2",
        "name" : "enhancedAKT2",
        "SUID" : 100,
        "rxnconID" : "enhancedAKT2",
        "type" : "boolean_and",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1440.3383788320627,
        "y" : 1672.8416137324377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "99",
        "shared_name" : "TSC2_[(Ser939)]-{p}",
        "name" : "TSC2_[(Ser939)]-{p}",
        "SUID" : 99,
        "rxnconID" : "TSC2_[(Ser939)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1199.1256739780076,
        "y" : 1342.591552734375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "98",
        "shared_name" : "AKT2_p+_TSC2_[(Ser939)]",
        "name" : "AKT2_p+_TSC2_[(Ser939)]",
        "SUID" : 98,
        "rxnconID" : "AKT2_p+_TSC2_[(Ser939)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1205.3973387930005,
        "y" : 1552.1616820918127
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1023",
        "shared_name" : "PHLPP1_p-_AKT2_[(S474)]",
        "name" : "PHLPP1_p-_AKT2_[(S474)]",
        "SUID" : 1023,
        "rxnconID" : "PHLPP1_p-_AKT2_[(S474)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1682.4566355952797,
        "y" : 1762.93017578125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1022",
        "shared_name" : "PP2A_p-_AKT2_[(T309)]",
        "name" : "PP2A_p-_AKT2_[(T309)]",
        "SUID" : 1022,
        "rxnconID" : "PP2A_p-_AKT2_[(T309)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1117.1026611328125,
        "y" : 1760.883915427994
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "95",
        "shared_name" : "AKT2_[(S474)]-{p}",
        "name" : "AKT2_[(S474)]-{p}",
        "SUID" : 95,
        "rxnconID" : "AKT2_[(S474)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1561.1709253267352,
        "y" : 1852.54833984375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "94",
        "shared_name" : "mTORC2_p+_AKT2_[(S474)]",
        "name" : "mTORC2_p+_AKT2_[(S474)]",
        "SUID" : 94,
        "rxnconID" : "mTORC2_p+_AKT2_[(S474)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1561.1714136079852,
        "y" : 1970.3564453125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "93",
        "shared_name" : "AKT2_[(T309)]-{p}",
        "name" : "AKT2_[(T309)]-{p}",
        "SUID" : 93,
        "rxnconID" : "AKT2_[(T309)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1365.3061792329852,
        "y" : 1848.58349609375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "92",
        "shared_name" : "PDK1_p+_AKT2_[(T309)]",
        "name" : "PDK1_p+_AKT2_[(T309)]",
        "SUID" : 92,
        "rxnconID" : "PDK1_p+_AKT2_[(T309)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1365.7959253267352,
        "y" : 1970.378173828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "91",
        "shared_name" : "AKT2_[PI]_i-_PI_[PH]",
        "name" : "AKT2_[PI]_i-_PI_[PH]",
        "SUID" : 91,
        "rxnconID" : "AKT2_[PI]_i-_PI_[PH]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1315.7671167329852,
        "y" : 2210.348876953125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "90",
        "shared_name" : "PIP3",
        "name" : "PIP3",
        "SUID" : 90,
        "rxnconID" : "PIP3",
        "type" : "boolean_and",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1458.3095972017352,
        "y" : 2317.588134765625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "89",
        "shared_name" : "AKT2_[PI]--PI_[PH]",
        "name" : "AKT2_[PI]--PI_[PH]",
        "SUID" : 89,
        "rxnconID" : "AKT2_[PI]--PI_[PH]",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1456.8523218111102,
        "y" : 2082.41650390625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "88",
        "shared_name" : "AKT2_[PI]_i+_PI_[PH]",
        "name" : "AKT2_[PI]_i+_PI_[PH]",
        "SUID" : 88,
        "rxnconID" : "AKT2_[PI]_i+_PI_[PH]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1604.9051782564227,
        "y" : 2187.93798828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "87",
        "shared_name" : "INPP4B_p-_PI_[(4)]",
        "name" : "INPP4B_p-_PI_[(4)]",
        "SUID" : 87,
        "rxnconID" : "INPP4B_p-_PI_[(4)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1014.3414605647918,
        "y" : 2799.9288523491155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "86",
        "shared_name" : "PIPP_p-_PI_[(5)]",
        "name" : "PIPP_p-_PI_[(5)]",
        "SUID" : 86,
        "rxnconID" : "PIPP_p-_PI_[(5)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 2041.5469129927606,
        "y" : 2726.7139051802606
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "85",
        "shared_name" : "PTEN_p-_PI_[(3)]",
        "name" : "PTEN_p-_PI_[(3)]",
        "SUID" : 85,
        "rxnconID" : "PTEN_p-_PI_[(3)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1987.5704345703125,
        "y" : 2372.554367373854
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84",
        "shared_name" : "PI45",
        "name" : "PI45",
        "SUID" : 84,
        "rxnconID" : "PI45",
        "type" : "boolean_and",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1448.8841552734375,
        "y" : 2431.051513671875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "83",
        "shared_name" : "[activatedPI3K]",
        "name" : "[activatedPI3K]",
        "SUID" : 83,
        "rxnconID" : "[activatedPI3K]",
        "type" : "output",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1707.6864013671875,
        "y" : 2771.887939453125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82",
        "shared_name" : "PI_[(3)]-{p}",
        "name" : "PI_[(3)]-{p}",
        "SUID" : 82,
        "rxnconID" : "PI_[(3)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1676.487150249063,
        "y" : 2351.654036550313
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81",
        "shared_name" : "PI3K_p+_PI_[(3)]",
        "name" : "PI3K_p+_PI_[(3)]",
        "SUID" : 81,
        "rxnconID" : "PI3K_p+_PI_[(3)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1693.2484271687335,
        "y" : 2614.783935546875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80",
        "shared_name" : "SYNJ2_p-_PI_[(5)]",
        "name" : "SYNJ2_p-_PI_[(5)]",
        "SUID" : 80,
        "rxnconID" : "SYNJ2_p-_PI_[(5)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1113.5411191497292,
        "y" : 2499.778526460365
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "79",
        "shared_name" : "SAC1M1L_p-_PI_[(4)]",
        "name" : "SAC1M1L_p-_PI_[(4)]",
        "SUID" : 79,
        "rxnconID" : "SAC1M1L_p-_PI_[(4)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1041.30029296875,
        "y" : 2972.068131418437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "78",
        "shared_name" : "PI4",
        "name" : "PI4",
        "SUID" : 78,
        "rxnconID" : "PI4",
        "type" : "boolean_and",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1265.6202392578125,
        "y" : 2730.933837890625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "77",
        "shared_name" : "PI_[(5)]-{p}",
        "name" : "PI_[(5)]-{p}",
        "SUID" : 77,
        "rxnconID" : "PI_[(5)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1450.8086317427603,
        "y" : 2598.564453125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "76",
        "shared_name" : "PIPK1alpha_p+_PI_[(5)]",
        "name" : "PIPK1alpha_p+_PI_[(5)]",
        "SUID" : 76,
        "rxnconID" : "PIPK1alpha_p+_PI_[(5)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1440.8524549849478,
        "y" : 2682.6474609375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "75",
        "shared_name" : "PI_[(4)]-{p}",
        "name" : "PI_[(4)]-{p}",
        "SUID" : 75,
        "rxnconID" : "PI_[(4)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1263.6162950150522,
        "y" : 2872.4169921875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "74",
        "shared_name" : "PI4K3alpha_p+_PI_[(4)]",
        "name" : "PI4K3alpha_p+_PI_[(4)]",
        "SUID" : 74,
        "rxnconID" : "PI4K3alpha_p+_PI_[(4)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1265.576011811927,
        "y" : 3000.584678804115
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "73",
        "shared_name" : "IRS_[pY]_ppi-_PI3K_[SH2]",
        "name" : "IRS_[pY]_ppi-_PI3K_[SH2]",
        "SUID" : 73,
        "rxnconID" : "IRS_[pY]_ppi-_PI3K_[SH2]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1881.7240370161978,
        "y" : 2923.8338922054168
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "72",
        "shared_name" : "IRS_[pY]--PI3K_[SH2]",
        "name" : "IRS_[pY]--PI3K_[SH2]",
        "SUID" : 72,
        "rxnconID" : "IRS_[pY]--PI3K_[SH2]",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1710.7705458052606,
        "y" : 2881.802490234375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "71",
        "shared_name" : "IRS_[pY]_ppi+_PI3K_[SH2]",
        "name" : "IRS_[pY]_ppi+_PI3K_[SH2]",
        "SUID" : 71,
        "rxnconID" : "IRS_[pY]_ppi+_PI3K_[SH2]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1711.3738172896356,
        "y" : 3021.192626953125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "70",
        "shared_name" : "RTK_p-_IRS_[(RTK)]",
        "name" : "RTK_p-_IRS_[(RTK)]",
        "SUID" : 70,
        "rxnconID" : "RTK_p-_IRS_[(RTK)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1816.5413453661645,
        "y" : 3188.2392016904205
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "69",
        "shared_name" : "[activatedEGFR]",
        "name" : "[activatedEGFR]",
        "SUID" : 69,
        "rxnconID" : "[activatedEGFR]",
        "type" : "output",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1606.7012939453125,
        "y" : 3368.9263762916157
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "68",
        "shared_name" : "IRS_[(RTK)]-{p}",
        "name" : "IRS_[(RTK)]-{p}",
        "SUID" : 68,
        "rxnconID" : "IRS_[(RTK)]-{p}",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1605.7059595064227,
        "y" : 3113.94970703125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "67",
        "shared_name" : "RTK_p+_IRS_[(RTK)]",
        "name" : "RTK_p+_IRS_[(RTK)]",
        "SUID" : 67,
        "rxnconID" : "RTK_p+_IRS_[(RTK)]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1605.12548828125,
        "y" : 3277.68701171875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "66",
        "shared_name" : "mitogen_[EGFR]_ppi-_EGFR_[mitogen]",
        "name" : "mitogen_[EGFR]_ppi-_EGFR_[mitogen]",
        "SUID" : 66,
        "rxnconID" : "mitogen_[EGFR]_ppi-_EGFR_[mitogen]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1804.6279296875,
        "y" : 3367.93408203125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "65",
        "shared_name" : "[mitogen]",
        "name" : "[mitogen]",
        "SUID" : 65,
        "rxnconID" : "[mitogen]",
        "type" : "input",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1580.3369140625,
        "y" : 3698.81787109375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "64",
        "shared_name" : "[EGFR]",
        "name" : "[EGFR]",
        "SUID" : 64,
        "rxnconID" : "[EGFR]",
        "type" : "input",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1664.8531494140625,
        "y" : 3701.075927734375
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "63",
        "shared_name" : "EGFR_[mitogen]--mitogen_[EGFR]",
        "name" : "EGFR_[mitogen]--mitogen_[EGFR]",
        "SUID" : 63,
        "rxnconID" : "EGFR_[mitogen]--mitogen_[EGFR]",
        "type" : "state",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1617.413330078125,
        "y" : 3474.981201171875
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "62",
        "shared_name" : "mitogen_[EGFR]_ppi+_EGFR_[mitogen]",
        "name" : "mitogen_[EGFR]_ppi+_EGFR_[mitogen]",
        "SUID" : 62,
        "rxnconID" : "mitogen_[EGFR]_ppi+_EGFR_[mitogen]",
        "type" : "reaction",
        "selected" : false,
        "attr_dict" : "None"
      },
      "position" : {
        "x" : 1623.814697265625,
        "y" : 3596.05859375
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "1186",
        "source" : "156",
        "target" : "154",
        "shared_name" : "eIF4E_[A001]_ppi-_eIF4G_[A002] (directed) eIF4E_[A001]--eIF4G_[A002]",
        "name" : "eIF4E_[A001]_ppi-_eIF4G_[A002] (directed) eIF4E_[A001]--eIF4G_[A002]",
        "interaction" : "consume",
        "SUID" : 1186,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1185",
        "source" : "155",
        "target" : "153",
        "shared_name" : "[eIF4G] (directed) eIF4E_[A001]_ppi+_eIF4G_[A002]",
        "name" : "[eIF4G] (directed) eIF4E_[A001]_ppi+_eIF4G_[A002]",
        "interaction" : "!",
        "SUID" : 1185,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1184",
        "source" : "154",
        "target" : "157",
        "shared_name" : "eIF4E_[A001]--eIF4G_[A002] (directed) [Output]",
        "name" : "eIF4E_[A001]--eIF4G_[A002] (directed) [Output]",
        "interaction" : "!",
        "SUID" : 1184,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1183",
        "source" : "154",
        "target" : "156",
        "shared_name" : "eIF4E_[A001]--eIF4G_[A002] (directed) eIF4E_[A001]_ppi-_eIF4G_[A002]",
        "name" : "eIF4E_[A001]--eIF4G_[A002] (directed) eIF4E_[A001]_ppi-_eIF4G_[A002]",
        "interaction" : "ss",
        "SUID" : 1183,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1182",
        "source" : "153",
        "target" : "154",
        "shared_name" : "eIF4E_[A001]_ppi+_eIF4G_[A002] (directed) eIF4E_[A001]--eIF4G_[A002]",
        "name" : "eIF4E_[A001]_ppi+_eIF4G_[A002] (directed) eIF4E_[A001]--eIF4G_[A002]",
        "interaction" : "produce",
        "SUID" : 1182,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1181",
        "source" : "152",
        "target" : "142",
        "shared_name" : "PPM1G_p-_EIF4EBP1_[(Thr70)] (directed) EIF4EBP1_[(Thr70)]-{p}",
        "name" : "PPM1G_p-_EIF4EBP1_[(Thr70)] (directed) EIF4EBP1_[(Thr70)]-{p}",
        "interaction" : "consume",
        "SUID" : 1181,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1180",
        "source" : "151",
        "target" : "141",
        "shared_name" : "PPM1G_p-_EIF4EBP1_[(Ser65)] (directed) EIF4EBP1_[(Ser65)]-{p}",
        "name" : "PPM1G_p-_EIF4EBP1_[(Ser65)] (directed) EIF4EBP1_[(Ser65)]-{p}",
        "interaction" : "consume",
        "SUID" : 1180,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1179",
        "source" : "150",
        "target" : "139",
        "shared_name" : "PPM1G_p-_EIF4EBP1_[(Thr46)] (directed) EIF4EBP1_[(Thr46)]-{p}",
        "name" : "PPM1G_p-_EIF4EBP1_[(Thr46)] (directed) EIF4EBP1_[(Thr46)]-{p}",
        "interaction" : "consume",
        "SUID" : 1179,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1178",
        "source" : "149",
        "target" : "140",
        "shared_name" : "PPM1G_p-_EIF4EBP1_[(Thr37)] (directed) EIF4EBP1_[(Thr37)]-{p}",
        "name" : "PPM1G_p-_EIF4EBP1_[(Thr37)] (directed) EIF4EBP1_[(Thr37)]-{p}",
        "interaction" : "consume",
        "SUID" : 1178,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1177",
        "source" : "148",
        "target" : "142",
        "shared_name" : "mTORC1_p+_EIF4EBP1_[(Thr70)] (directed) EIF4EBP1_[(Thr70)]-{p}",
        "name" : "mTORC1_p+_EIF4EBP1_[(Thr70)] (directed) EIF4EBP1_[(Thr70)]-{p}",
        "interaction" : "produce",
        "SUID" : 1177,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1176",
        "source" : "147",
        "target" : "141",
        "shared_name" : "mTORC1_p+_EIF4EBP1_[(Ser65)] (directed) EIF4EBP1_[(Ser65)]-{p}",
        "name" : "mTORC1_p+_EIF4EBP1_[(Ser65)] (directed) EIF4EBP1_[(Ser65)]-{p}",
        "interaction" : "produce",
        "SUID" : 1176,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1175",
        "source" : "146",
        "target" : "139",
        "shared_name" : "mTORC1_p+_EIF4EBP1_[(Thr46)] (directed) EIF4EBP1_[(Thr46)]-{p}",
        "name" : "mTORC1_p+_EIF4EBP1_[(Thr46)] (directed) EIF4EBP1_[(Thr46)]-{p}",
        "interaction" : "produce",
        "SUID" : 1175,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1174",
        "source" : "145",
        "target" : "148",
        "shared_name" : "mTORC1 (directed) mTORC1_p+_EIF4EBP1_[(Thr70)]",
        "name" : "mTORC1 (directed) mTORC1_p+_EIF4EBP1_[(Thr70)]",
        "interaction" : "!",
        "SUID" : 1174,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1173",
        "source" : "145",
        "target" : "147",
        "shared_name" : "mTORC1 (directed) mTORC1_p+_EIF4EBP1_[(Ser65)]",
        "name" : "mTORC1 (directed) mTORC1_p+_EIF4EBP1_[(Ser65)]",
        "interaction" : "!",
        "SUID" : 1173,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1172",
        "source" : "145",
        "target" : "146",
        "shared_name" : "mTORC1 (directed) mTORC1_p+_EIF4EBP1_[(Thr46)]",
        "name" : "mTORC1 (directed) mTORC1_p+_EIF4EBP1_[(Thr46)]",
        "interaction" : "!",
        "SUID" : 1172,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1171",
        "source" : "145",
        "target" : "144",
        "shared_name" : "mTORC1 (directed) mTORC1_p+_EIF4EBP1_[(Thr37)]",
        "name" : "mTORC1 (directed) mTORC1_p+_EIF4EBP1_[(Thr37)]",
        "interaction" : "!",
        "SUID" : 1171,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1170",
        "source" : "144",
        "target" : "140",
        "shared_name" : "mTORC1_p+_EIF4EBP1_[(Thr37)] (directed) EIF4EBP1_[(Thr37)]-{p}",
        "name" : "mTORC1_p+_EIF4EBP1_[(Thr37)] (directed) EIF4EBP1_[(Thr37)]-{p}",
        "interaction" : "produce",
        "SUID" : 1170,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1169",
        "source" : "143",
        "target" : "135",
        "shared_name" : "eIF4E_[A001]_ppi-_EIF4EBP1_[A001] (directed) EIF4EBP1_[A001]--eIF4E_[A001]",
        "name" : "eIF4E_[A001]_ppi-_EIF4EBP1_[A001] (directed) EIF4EBP1_[A001]--eIF4E_[A001]",
        "interaction" : "consume",
        "SUID" : 1169,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1168",
        "source" : "142",
        "target" : "152",
        "shared_name" : "EIF4EBP1_[(Thr70)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Thr70)]",
        "name" : "EIF4EBP1_[(Thr70)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Thr70)]",
        "interaction" : "ss",
        "SUID" : 1168,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1167",
        "source" : "142",
        "target" : "147",
        "shared_name" : "EIF4EBP1_[(Thr70)]-{p} (directed) mTORC1_p+_EIF4EBP1_[(Ser65)]",
        "name" : "EIF4EBP1_[(Thr70)]-{p} (directed) mTORC1_p+_EIF4EBP1_[(Ser65)]",
        "interaction" : "!",
        "SUID" : 1167,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1166",
        "source" : "142",
        "target" : "138",
        "shared_name" : "EIF4EBP1_[(Thr70)]-{p} (directed) translation",
        "name" : "EIF4EBP1_[(Thr70)]-{p} (directed) translation",
        "interaction" : "AND",
        "SUID" : 1166,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1165",
        "source" : "141",
        "target" : "151",
        "shared_name" : "EIF4EBP1_[(Ser65)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Ser65)]",
        "name" : "EIF4EBP1_[(Ser65)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Ser65)]",
        "interaction" : "ss",
        "SUID" : 1165,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1164",
        "source" : "141",
        "target" : "138",
        "shared_name" : "EIF4EBP1_[(Ser65)]-{p} (directed) translation",
        "name" : "EIF4EBP1_[(Ser65)]-{p} (directed) translation",
        "interaction" : "AND",
        "SUID" : 1164,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1163",
        "source" : "140",
        "target" : "149",
        "shared_name" : "EIF4EBP1_[(Thr37)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Thr37)]",
        "name" : "EIF4EBP1_[(Thr37)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Thr37)]",
        "interaction" : "ss",
        "SUID" : 1163,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1162",
        "source" : "140",
        "target" : "148",
        "shared_name" : "EIF4EBP1_[(Thr37)]-{p} (directed) mTORC1_p+_EIF4EBP1_[(Thr70)]",
        "name" : "EIF4EBP1_[(Thr37)]-{p} (directed) mTORC1_p+_EIF4EBP1_[(Thr70)]",
        "interaction" : "!",
        "SUID" : 1162,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1161",
        "source" : "140",
        "target" : "147",
        "shared_name" : "EIF4EBP1_[(Thr37)]-{p} (directed) mTORC1_p+_EIF4EBP1_[(Ser65)]",
        "name" : "EIF4EBP1_[(Thr37)]-{p} (directed) mTORC1_p+_EIF4EBP1_[(Ser65)]",
        "interaction" : "!",
        "SUID" : 1161,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1160",
        "source" : "140",
        "target" : "138",
        "shared_name" : "EIF4EBP1_[(Thr37)]-{p} (directed) translation",
        "name" : "EIF4EBP1_[(Thr37)]-{p} (directed) translation",
        "interaction" : "AND",
        "SUID" : 1160,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1159",
        "source" : "139",
        "target" : "150",
        "shared_name" : "EIF4EBP1_[(Thr46)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Thr46)]",
        "name" : "EIF4EBP1_[(Thr46)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Thr46)]",
        "interaction" : "ss",
        "SUID" : 1159,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1158",
        "source" : "139",
        "target" : "148",
        "shared_name" : "EIF4EBP1_[(Thr46)]-{p} (directed) mTORC1_p+_EIF4EBP1_[(Thr70)]",
        "name" : "EIF4EBP1_[(Thr46)]-{p} (directed) mTORC1_p+_EIF4EBP1_[(Thr70)]",
        "interaction" : "!",
        "SUID" : 1158,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1157",
        "source" : "139",
        "target" : "147",
        "shared_name" : "EIF4EBP1_[(Thr46)]-{p} (directed) mTORC1_p+_EIF4EBP1_[(Ser65)]",
        "name" : "EIF4EBP1_[(Thr46)]-{p} (directed) mTORC1_p+_EIF4EBP1_[(Ser65)]",
        "interaction" : "!",
        "SUID" : 1157,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1156",
        "source" : "139",
        "target" : "138",
        "shared_name" : "EIF4EBP1_[(Thr46)]-{p} (directed) translation",
        "name" : "EIF4EBP1_[(Thr46)]-{p} (directed) translation",
        "interaction" : "AND",
        "SUID" : 1156,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1155",
        "source" : "138",
        "target" : "153",
        "shared_name" : "translation (directed) eIF4E_[A001]_ppi+_eIF4G_[A002]",
        "name" : "translation (directed) eIF4E_[A001]_ppi+_eIF4G_[A002]",
        "interaction" : "!",
        "SUID" : 1155,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1154",
        "source" : "138",
        "target" : "143",
        "shared_name" : "translation (directed) eIF4E_[A001]_ppi-_EIF4EBP1_[A001]",
        "name" : "translation (directed) eIF4E_[A001]_ppi-_EIF4EBP1_[A001]",
        "interaction" : "!",
        "SUID" : 1154,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1153",
        "source" : "138",
        "target" : "134",
        "shared_name" : "translation (directed) eIF4E_[A001]_ppi+_EIF4EBP1_[A001]",
        "name" : "translation (directed) eIF4E_[A001]_ppi+_EIF4EBP1_[A001]",
        "interaction" : "x",
        "SUID" : 1153,
        "shared_interaction" : "x",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1152",
        "source" : "137",
        "target" : "153",
        "shared_name" : "[eIF4E] (directed) eIF4E_[A001]_ppi+_eIF4G_[A002]",
        "name" : "[eIF4E] (directed) eIF4E_[A001]_ppi+_eIF4G_[A002]",
        "interaction" : "!",
        "SUID" : 1152,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1151",
        "source" : "137",
        "target" : "134",
        "shared_name" : "[eIF4E] (directed) eIF4E_[A001]_ppi+_EIF4EBP1_[A001]",
        "name" : "[eIF4E] (directed) eIF4E_[A001]_ppi+_EIF4EBP1_[A001]",
        "interaction" : "!",
        "SUID" : 1151,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1150",
        "source" : "136",
        "target" : "134",
        "shared_name" : "[EIF4EBP1] (directed) eIF4E_[A001]_ppi+_EIF4EBP1_[A001]",
        "name" : "[EIF4EBP1] (directed) eIF4E_[A001]_ppi+_EIF4EBP1_[A001]",
        "interaction" : "!",
        "SUID" : 1150,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1149",
        "source" : "135",
        "target" : "153",
        "shared_name" : "EIF4EBP1_[A001]--eIF4E_[A001] (directed) eIF4E_[A001]_ppi+_eIF4G_[A002]",
        "name" : "EIF4EBP1_[A001]--eIF4E_[A001] (directed) eIF4E_[A001]_ppi+_eIF4G_[A002]",
        "interaction" : "x",
        "SUID" : 1149,
        "shared_interaction" : "x",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1148",
        "source" : "135",
        "target" : "148",
        "shared_name" : "EIF4EBP1_[A001]--eIF4E_[A001] (directed) mTORC1_p+_EIF4EBP1_[(Thr70)]",
        "name" : "EIF4EBP1_[A001]--eIF4E_[A001] (directed) mTORC1_p+_EIF4EBP1_[(Thr70)]",
        "interaction" : "!",
        "SUID" : 1148,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1147",
        "source" : "135",
        "target" : "147",
        "shared_name" : "EIF4EBP1_[A001]--eIF4E_[A001] (directed) mTORC1_p+_EIF4EBP1_[(Ser65)]",
        "name" : "EIF4EBP1_[A001]--eIF4E_[A001] (directed) mTORC1_p+_EIF4EBP1_[(Ser65)]",
        "interaction" : "!",
        "SUID" : 1147,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1146",
        "source" : "135",
        "target" : "146",
        "shared_name" : "EIF4EBP1_[A001]--eIF4E_[A001] (directed) mTORC1_p+_EIF4EBP1_[(Thr46)]",
        "name" : "EIF4EBP1_[A001]--eIF4E_[A001] (directed) mTORC1_p+_EIF4EBP1_[(Thr46)]",
        "interaction" : "!",
        "SUID" : 1146,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1145",
        "source" : "135",
        "target" : "144",
        "shared_name" : "EIF4EBP1_[A001]--eIF4E_[A001] (directed) mTORC1_p+_EIF4EBP1_[(Thr37)]",
        "name" : "EIF4EBP1_[A001]--eIF4E_[A001] (directed) mTORC1_p+_EIF4EBP1_[(Thr37)]",
        "interaction" : "!",
        "SUID" : 1145,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1144",
        "source" : "135",
        "target" : "143",
        "shared_name" : "EIF4EBP1_[A001]--eIF4E_[A001] (directed) eIF4E_[A001]_ppi-_EIF4EBP1_[A001]",
        "name" : "EIF4EBP1_[A001]--eIF4E_[A001] (directed) eIF4E_[A001]_ppi-_EIF4EBP1_[A001]",
        "interaction" : "ss",
        "SUID" : 1144,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1143",
        "source" : "134",
        "target" : "135",
        "shared_name" : "eIF4E_[A001]_ppi+_EIF4EBP1_[A001] (directed) EIF4EBP1_[A001]--eIF4E_[A001]",
        "name" : "eIF4E_[A001]_ppi+_EIF4EBP1_[A001] (directed) EIF4EBP1_[A001]--eIF4E_[A001]",
        "interaction" : "produce",
        "SUID" : 1143,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1142",
        "source" : "133",
        "target" : "130",
        "shared_name" : "[mTOR] (directed) mTOR_[Raptor]_ppi+_Raptor_[mTOR]",
        "name" : "[mTOR] (directed) mTOR_[Raptor]_ppi+_Raptor_[mTOR]",
        "interaction" : "!",
        "SUID" : 1142,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1141",
        "source" : "132",
        "target" : "130",
        "shared_name" : "[Raptor] (directed) mTOR_[Raptor]_ppi+_Raptor_[mTOR]",
        "name" : "[Raptor] (directed) mTOR_[Raptor]_ppi+_Raptor_[mTOR]",
        "interaction" : "!",
        "SUID" : 1141,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1140",
        "source" : "131",
        "target" : "145",
        "shared_name" : "Raptor_[mTOR]--mTOR_[Raptor] (directed) mTORC1",
        "name" : "Raptor_[mTOR]--mTOR_[Raptor] (directed) mTORC1",
        "interaction" : "AND",
        "SUID" : 1140,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1139",
        "source" : "130",
        "target" : "131",
        "shared_name" : "mTOR_[Raptor]_ppi+_Raptor_[mTOR] (directed) Raptor_[mTOR]--mTOR_[Raptor]",
        "name" : "mTOR_[Raptor]_ppi+_Raptor_[mTOR] (directed) Raptor_[mTOR]--mTOR_[Raptor]",
        "interaction" : "produce",
        "SUID" : 1139,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1138",
        "source" : "582",
        "target" : "583",
        "shared_name" : "RHEB_[switch1DSYDPTIEN]_ppi-_mTOR_[FATfα2fα3] (directed) RHEB_[switch1DSYDPTIEN]--mTOR_[FATfα2fα3]",
        "name" : "RHEB_[switch1DSYDPTIEN]_ppi-_mTOR_[FATfα2fα3] (directed) RHEB_[switch1DSYDPTIEN]--mTOR_[FATfα2fα3]",
        "interaction" : "consume",
        "SUID" : 1138,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1137",
        "source" : "583",
        "target" : "145",
        "shared_name" : "RHEB_[switch1DSYDPTIEN]--mTOR_[FATfα2fα3] (directed) mTORC1",
        "name" : "RHEB_[switch1DSYDPTIEN]--mTOR_[FATfα2fα3] (directed) mTORC1",
        "interaction" : "AND",
        "SUID" : 1137,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1136",
        "source" : "583",
        "target" : "582",
        "shared_name" : "RHEB_[switch1DSYDPTIEN]--mTOR_[FATfα2fα3] (directed) RHEB_[switch1DSYDPTIEN]_ppi-_mTOR_[FATfα2fα3]",
        "name" : "RHEB_[switch1DSYDPTIEN]--mTOR_[FATfα2fα3] (directed) RHEB_[switch1DSYDPTIEN]_ppi-_mTOR_[FATfα2fα3]",
        "interaction" : "ss",
        "SUID" : 1136,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1135",
        "source" : "584",
        "target" : "583",
        "shared_name" : "RHEB_[switch1DSYDPTIEN]_ppi+_mTOR_[FATfα2fα3] (directed) RHEB_[switch1DSYDPTIEN]--mTOR_[FATfα2fα3]",
        "name" : "RHEB_[switch1DSYDPTIEN]_ppi+_mTOR_[FATfα2fα3] (directed) RHEB_[switch1DSYDPTIEN]--mTOR_[FATfα2fα3]",
        "interaction" : "produce",
        "SUID" : 1135,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1134",
        "source" : "585",
        "target" : "586",
        "shared_name" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi-_mTOR_[Nheatnα3tonα7] (directed) RHEB_[switch2GQDEYSIFPQTYSIDIN]--mTOR_[Nheatnα3tonα7]",
        "name" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi-_mTOR_[Nheatnα3tonα7] (directed) RHEB_[switch2GQDEYSIFPQTYSIDIN]--mTOR_[Nheatnα3tonα7]",
        "interaction" : "consume",
        "SUID" : 1134,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1133",
        "source" : "586",
        "target" : "145",
        "shared_name" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]--mTOR_[Nheatnα3tonα7] (directed) mTORC1",
        "name" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]--mTOR_[Nheatnα3tonα7] (directed) mTORC1",
        "interaction" : "AND",
        "SUID" : 1133,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1132",
        "source" : "586",
        "target" : "585",
        "shared_name" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]--mTOR_[Nheatnα3tonα7] (directed) RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi-_mTOR_[Nheatnα3tonα7]",
        "name" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]--mTOR_[Nheatnα3tonα7] (directed) RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi-_mTOR_[Nheatnα3tonα7]",
        "interaction" : "ss",
        "SUID" : 1132,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1131",
        "source" : "587",
        "target" : "586",
        "shared_name" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi+_mTOR_[Nheatnα3tonα7] (directed) RHEB_[switch2GQDEYSIFPQTYSIDIN]--mTOR_[Nheatnα3tonα7]",
        "name" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi+_mTOR_[Nheatnα3tonα7] (directed) RHEB_[switch2GQDEYSIFPQTYSIDIN]--mTOR_[Nheatnα3tonα7]",
        "interaction" : "produce",
        "SUID" : 1131,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1130",
        "source" : "588",
        "target" : "589",
        "shared_name" : "RHEB_[switch1]_ppi-_mTOR_[Mheatmα2mα3mα4] (directed) RHEB_[switch1]--mTOR_[Mheatmα2mα3mα4]",
        "name" : "RHEB_[switch1]_ppi-_mTOR_[Mheatmα2mα3mα4] (directed) RHEB_[switch1]--mTOR_[Mheatmα2mα3mα4]",
        "interaction" : "consume",
        "SUID" : 1130,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1129",
        "source" : "589",
        "target" : "145",
        "shared_name" : "RHEB_[switch1]--mTOR_[Mheatmα2mα3mα4] (directed) mTORC1",
        "name" : "RHEB_[switch1]--mTOR_[Mheatmα2mα3mα4] (directed) mTORC1",
        "interaction" : "AND",
        "SUID" : 1129,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1128",
        "source" : "589",
        "target" : "588",
        "shared_name" : "RHEB_[switch1]--mTOR_[Mheatmα2mα3mα4] (directed) RHEB_[switch1]_ppi-_mTOR_[Mheatmα2mα3mα4]",
        "name" : "RHEB_[switch1]--mTOR_[Mheatmα2mα3mα4] (directed) RHEB_[switch1]_ppi-_mTOR_[Mheatmα2mα3mα4]",
        "interaction" : "ss",
        "SUID" : 1128,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1127",
        "source" : "590",
        "target" : "589",
        "shared_name" : "RHEB_[switch1]_ppi+_mTOR_[Mheatmα2mα3mα4] (directed) RHEB_[switch1]--mTOR_[Mheatmα2mα3mα4]",
        "name" : "RHEB_[switch1]_ppi+_mTOR_[Mheatmα2mα3mα4] (directed) RHEB_[switch1]--mTOR_[Mheatmα2mα3mα4]",
        "interaction" : "produce",
        "SUID" : 1127,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1126",
        "source" : "120",
        "target" : "119",
        "shared_name" : "TSC2_gap_RHEB_[(G)] (directed) RHEB_[(G)]-{gtp}",
        "name" : "TSC2_gap_RHEB_[(G)] (directed) RHEB_[(G)]-{gtp}",
        "interaction" : "consume",
        "SUID" : 1126,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1125",
        "source" : "119",
        "target" : "584",
        "shared_name" : "RHEB_[(G)]-{gtp} (directed) RHEB_[switch1DSYDPTIEN]_ppi+_mTOR_[FATfα2fα3]",
        "name" : "RHEB_[(G)]-{gtp} (directed) RHEB_[switch1DSYDPTIEN]_ppi+_mTOR_[FATfα2fα3]",
        "interaction" : "!",
        "SUID" : 1125,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1124",
        "source" : "119",
        "target" : "587",
        "shared_name" : "RHEB_[(G)]-{gtp} (directed) RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi+_mTOR_[Nheatnα3tonα7]",
        "name" : "RHEB_[(G)]-{gtp} (directed) RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi+_mTOR_[Nheatnα3tonα7]",
        "interaction" : "!",
        "SUID" : 1124,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1123",
        "source" : "119",
        "target" : "590",
        "shared_name" : "RHEB_[(G)]-{gtp} (directed) RHEB_[switch1]_ppi+_mTOR_[Mheatmα2mα3mα4]",
        "name" : "RHEB_[(G)]-{gtp} (directed) RHEB_[switch1]_ppi+_mTOR_[Mheatmα2mα3mα4]",
        "interaction" : "!",
        "SUID" : 1123,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1122",
        "source" : "119",
        "target" : "120",
        "shared_name" : "RHEB_[(G)]-{gtp} (directed) TSC2_gap_RHEB_[(G)]",
        "name" : "RHEB_[(G)]-{gtp} (directed) TSC2_gap_RHEB_[(G)]",
        "interaction" : "ss",
        "SUID" : 1122,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1121",
        "source" : "118",
        "target" : "119",
        "shared_name" : "GTP_gef_RHEB_[(G)] (directed) RHEB_[(G)]-{gtp}",
        "name" : "GTP_gef_RHEB_[(G)] (directed) RHEB_[(G)]-{gtp}",
        "interaction" : "produce",
        "SUID" : 1121,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1120",
        "source" : "117",
        "target" : "115",
        "shared_name" : "TSC1_[Cterminus]_ppi-_TSC2_[Nterminus] (directed) TSC1_[Cterminus]--TSC2_[Nterminus]",
        "name" : "TSC1_[Cterminus]_ppi-_TSC2_[Nterminus] (directed) TSC1_[Cterminus]--TSC2_[Nterminus]",
        "interaction" : "consume",
        "SUID" : 1120,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1119",
        "source" : "116",
        "target" : "118",
        "shared_name" : "destabilization (directed) GTP_gef_RHEB_[(G)]",
        "name" : "destabilization (directed) GTP_gef_RHEB_[(G)]",
        "interaction" : "!",
        "SUID" : 1119,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1118",
        "source" : "116",
        "target" : "117",
        "shared_name" : "destabilization (directed) TSC1_[Cterminus]_ppi-_TSC2_[Nterminus]",
        "name" : "destabilization (directed) TSC1_[Cterminus]_ppi-_TSC2_[Nterminus]",
        "interaction" : "!",
        "SUID" : 1118,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1117",
        "source" : "116",
        "target" : "114",
        "shared_name" : "destabilization (directed) TSC1_[Cterminus]_ppi+_TSC2_[Nterminus]",
        "name" : "destabilization (directed) TSC1_[Cterminus]_ppi+_TSC2_[Nterminus]",
        "interaction" : "x",
        "SUID" : 1117,
        "shared_interaction" : "x",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1116",
        "source" : "115",
        "target" : "120",
        "shared_name" : "TSC1_[Cterminus]--TSC2_[Nterminus] (directed) TSC2_gap_RHEB_[(G)]",
        "name" : "TSC1_[Cterminus]--TSC2_[Nterminus] (directed) TSC2_gap_RHEB_[(G)]",
        "interaction" : "!",
        "SUID" : 1116,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1115",
        "source" : "115",
        "target" : "117",
        "shared_name" : "TSC1_[Cterminus]--TSC2_[Nterminus] (directed) TSC1_[Cterminus]_ppi-_TSC2_[Nterminus]",
        "name" : "TSC1_[Cterminus]--TSC2_[Nterminus] (directed) TSC1_[Cterminus]_ppi-_TSC2_[Nterminus]",
        "interaction" : "ss",
        "SUID" : 1115,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1114",
        "source" : "114",
        "target" : "115",
        "shared_name" : "TSC1_[Cterminus]_ppi+_TSC2_[Nterminus] (directed) TSC1_[Cterminus]--TSC2_[Nterminus]",
        "name" : "TSC1_[Cterminus]_ppi+_TSC2_[Nterminus] (directed) TSC1_[Cterminus]--TSC2_[Nterminus]",
        "interaction" : "produce",
        "SUID" : 1114,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1113",
        "source" : "1028",
        "target" : "106",
        "shared_name" : "PP5_p-_TSC2_[(Ser1130)] (directed) TSC2_[(Ser1130)]-{p}",
        "name" : "PP5_p-_TSC2_[(Ser1130)] (directed) TSC2_[(Ser1130)]-{p}",
        "interaction" : "consume",
        "SUID" : 1113,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1112",
        "source" : "1027",
        "target" : "104",
        "shared_name" : "PP5_p-_TSC2_[(Ser981)] (directed) TSC2_[(Ser981)]-{p}",
        "name" : "PP5_p-_TSC2_[(Ser981)] (directed) TSC2_[(Ser981)]-{p}",
        "interaction" : "consume",
        "SUID" : 1112,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1111",
        "source" : "1026",
        "target" : "102",
        "shared_name" : "PP5_p-_TSC2_[(Thr1462)] (directed) TSC2_[(Thr1462)]-{p}",
        "name" : "PP5_p-_TSC2_[(Thr1462)] (directed) TSC2_[(Thr1462)]-{p}",
        "interaction" : "consume",
        "SUID" : 1111,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1110",
        "source" : "1025",
        "target" : "99",
        "shared_name" : "PP5_p-_TSC2_[(Ser939)] (directed) TSC2_[(Ser939)]-{p}",
        "name" : "PP5_p-_TSC2_[(Ser939)] (directed) TSC2_[(Ser939)]-{p}",
        "interaction" : "consume",
        "SUID" : 1110,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1109",
        "source" : "1024",
        "target" : "108",
        "shared_name" : "unk_p-_PPM1G_[(AKT2)] (directed) PPM1G_[(AKT2)]-{p}",
        "name" : "unk_p-_PPM1G_[(AKT2)] (directed) PPM1G_[(AKT2)]-{p}",
        "interaction" : "consume",
        "SUID" : 1109,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1108",
        "source" : "108",
        "target" : "152",
        "shared_name" : "PPM1G_[(AKT2)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Thr70)]",
        "name" : "PPM1G_[(AKT2)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Thr70)]",
        "interaction" : "x",
        "SUID" : 1108,
        "shared_interaction" : "x",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1107",
        "source" : "108",
        "target" : "151",
        "shared_name" : "PPM1G_[(AKT2)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Ser65)]",
        "name" : "PPM1G_[(AKT2)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Ser65)]",
        "interaction" : "x",
        "SUID" : 1107,
        "shared_interaction" : "x",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1106",
        "source" : "108",
        "target" : "150",
        "shared_name" : "PPM1G_[(AKT2)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Thr46)]",
        "name" : "PPM1G_[(AKT2)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Thr46)]",
        "interaction" : "x",
        "SUID" : 1106,
        "shared_interaction" : "x",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1105",
        "source" : "108",
        "target" : "149",
        "shared_name" : "PPM1G_[(AKT2)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Thr37)]",
        "name" : "PPM1G_[(AKT2)]-{p} (directed) PPM1G_p-_EIF4EBP1_[(Thr37)]",
        "interaction" : "x",
        "SUID" : 1105,
        "shared_interaction" : "x",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1104",
        "source" : "108",
        "target" : "1024",
        "shared_name" : "PPM1G_[(AKT2)]-{p} (directed) unk_p-_PPM1G_[(AKT2)]",
        "name" : "PPM1G_[(AKT2)]-{p} (directed) unk_p-_PPM1G_[(AKT2)]",
        "interaction" : "ss",
        "SUID" : 1104,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1103",
        "source" : "107",
        "target" : "108",
        "shared_name" : "AKT2_p+_PPM1G_[(AKT2)] (directed) PPM1G_[(AKT2)]-{p}",
        "name" : "AKT2_p+_PPM1G_[(AKT2)] (directed) PPM1G_[(AKT2)]-{p}",
        "interaction" : "produce",
        "SUID" : 1103,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1102",
        "source" : "106",
        "target" : "116",
        "shared_name" : "TSC2_[(Ser1130)]-{p} (directed) destabilization",
        "name" : "TSC2_[(Ser1130)]-{p} (directed) destabilization",
        "interaction" : "AND",
        "SUID" : 1102,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1101",
        "source" : "106",
        "target" : "1028",
        "shared_name" : "TSC2_[(Ser1130)]-{p} (directed) PP5_p-_TSC2_[(Ser1130)]",
        "name" : "TSC2_[(Ser1130)]-{p} (directed) PP5_p-_TSC2_[(Ser1130)]",
        "interaction" : "ss",
        "SUID" : 1101,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1100",
        "source" : "105",
        "target" : "106",
        "shared_name" : "AKT2_p+_TSC2_[(Ser1130)] (directed) TSC2_[(Ser1130)]-{p}",
        "name" : "AKT2_p+_TSC2_[(Ser1130)] (directed) TSC2_[(Ser1130)]-{p}",
        "interaction" : "produce",
        "SUID" : 1100,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1099",
        "source" : "104",
        "target" : "116",
        "shared_name" : "TSC2_[(Ser981)]-{p} (directed) destabilization",
        "name" : "TSC2_[(Ser981)]-{p} (directed) destabilization",
        "interaction" : "AND",
        "SUID" : 1099,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1098",
        "source" : "104",
        "target" : "1027",
        "shared_name" : "TSC2_[(Ser981)]-{p} (directed) PP5_p-_TSC2_[(Ser981)]",
        "name" : "TSC2_[(Ser981)]-{p} (directed) PP5_p-_TSC2_[(Ser981)]",
        "interaction" : "ss",
        "SUID" : 1098,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1097",
        "source" : "103",
        "target" : "104",
        "shared_name" : "AKT2_p+_TSC2_[(Ser981)] (directed) TSC2_[(Ser981)]-{p}",
        "name" : "AKT2_p+_TSC2_[(Ser981)] (directed) TSC2_[(Ser981)]-{p}",
        "interaction" : "produce",
        "SUID" : 1097,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1096",
        "source" : "102",
        "target" : "116",
        "shared_name" : "TSC2_[(Thr1462)]-{p} (directed) destabilization",
        "name" : "TSC2_[(Thr1462)]-{p} (directed) destabilization",
        "interaction" : "AND",
        "SUID" : 1096,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1095",
        "source" : "102",
        "target" : "1026",
        "shared_name" : "TSC2_[(Thr1462)]-{p} (directed) PP5_p-_TSC2_[(Thr1462)]",
        "name" : "TSC2_[(Thr1462)]-{p} (directed) PP5_p-_TSC2_[(Thr1462)]",
        "interaction" : "ss",
        "SUID" : 1095,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1094",
        "source" : "101",
        "target" : "102",
        "shared_name" : "AKT2_p+_TSC2_[(Thr1462)] (directed) TSC2_[(Thr1462)]-{p}",
        "name" : "AKT2_p+_TSC2_[(Thr1462)] (directed) TSC2_[(Thr1462)]-{p}",
        "interaction" : "produce",
        "SUID" : 1094,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1093",
        "source" : "100",
        "target" : "1024",
        "shared_name" : "enhancedAKT2 (directed) unk_p-_PPM1G_[(AKT2)]",
        "name" : "enhancedAKT2 (directed) unk_p-_PPM1G_[(AKT2)]",
        "interaction" : "x",
        "SUID" : 1093,
        "shared_interaction" : "x",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1092",
        "source" : "100",
        "target" : "107",
        "shared_name" : "enhancedAKT2 (directed) AKT2_p+_PPM1G_[(AKT2)]",
        "name" : "enhancedAKT2 (directed) AKT2_p+_PPM1G_[(AKT2)]",
        "interaction" : "!",
        "SUID" : 1092,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1091",
        "source" : "100",
        "target" : "105",
        "shared_name" : "enhancedAKT2 (directed) AKT2_p+_TSC2_[(Ser1130)]",
        "name" : "enhancedAKT2 (directed) AKT2_p+_TSC2_[(Ser1130)]",
        "interaction" : "!",
        "SUID" : 1091,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1090",
        "source" : "100",
        "target" : "103",
        "shared_name" : "enhancedAKT2 (directed) AKT2_p+_TSC2_[(Ser981)]",
        "name" : "enhancedAKT2 (directed) AKT2_p+_TSC2_[(Ser981)]",
        "interaction" : "!",
        "SUID" : 1090,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1089",
        "source" : "100",
        "target" : "101",
        "shared_name" : "enhancedAKT2 (directed) AKT2_p+_TSC2_[(Thr1462)]",
        "name" : "enhancedAKT2 (directed) AKT2_p+_TSC2_[(Thr1462)]",
        "interaction" : "!",
        "SUID" : 1089,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1088",
        "source" : "100",
        "target" : "98",
        "shared_name" : "enhancedAKT2 (directed) AKT2_p+_TSC2_[(Ser939)]",
        "name" : "enhancedAKT2 (directed) AKT2_p+_TSC2_[(Ser939)]",
        "interaction" : "!",
        "SUID" : 1088,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1087",
        "source" : "99",
        "target" : "116",
        "shared_name" : "TSC2_[(Ser939)]-{p} (directed) destabilization",
        "name" : "TSC2_[(Ser939)]-{p} (directed) destabilization",
        "interaction" : "AND",
        "SUID" : 1087,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1086",
        "source" : "99",
        "target" : "1025",
        "shared_name" : "TSC2_[(Ser939)]-{p} (directed) PP5_p-_TSC2_[(Ser939)]",
        "name" : "TSC2_[(Ser939)]-{p} (directed) PP5_p-_TSC2_[(Ser939)]",
        "interaction" : "ss",
        "SUID" : 1086,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1085",
        "source" : "98",
        "target" : "99",
        "shared_name" : "AKT2_p+_TSC2_[(Ser939)] (directed) TSC2_[(Ser939)]-{p}",
        "name" : "AKT2_p+_TSC2_[(Ser939)] (directed) TSC2_[(Ser939)]-{p}",
        "interaction" : "produce",
        "SUID" : 1085,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1084",
        "source" : "1023",
        "target" : "95",
        "shared_name" : "PHLPP1_p-_AKT2_[(S474)] (directed) AKT2_[(S474)]-{p}",
        "name" : "PHLPP1_p-_AKT2_[(S474)] (directed) AKT2_[(S474)]-{p}",
        "interaction" : "consume",
        "SUID" : 1084,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1083",
        "source" : "1022",
        "target" : "93",
        "shared_name" : "PP2A_p-_AKT2_[(T309)] (directed) AKT2_[(T309)]-{p}",
        "name" : "PP2A_p-_AKT2_[(T309)] (directed) AKT2_[(T309)]-{p}",
        "interaction" : "consume",
        "SUID" : 1083,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1082",
        "source" : "95",
        "target" : "100",
        "shared_name" : "AKT2_[(S474)]-{p} (directed) enhancedAKT2",
        "name" : "AKT2_[(S474)]-{p} (directed) enhancedAKT2",
        "interaction" : "AND",
        "SUID" : 1082,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1081",
        "source" : "95",
        "target" : "1023",
        "shared_name" : "AKT2_[(S474)]-{p} (directed) PHLPP1_p-_AKT2_[(S474)]",
        "name" : "AKT2_[(S474)]-{p} (directed) PHLPP1_p-_AKT2_[(S474)]",
        "interaction" : "ss",
        "SUID" : 1081,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1080",
        "source" : "94",
        "target" : "95",
        "shared_name" : "mTORC2_p+_AKT2_[(S474)] (directed) AKT2_[(S474)]-{p}",
        "name" : "mTORC2_p+_AKT2_[(S474)] (directed) AKT2_[(S474)]-{p}",
        "interaction" : "produce",
        "SUID" : 1080,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1079",
        "source" : "93",
        "target" : "100",
        "shared_name" : "AKT2_[(T309)]-{p} (directed) enhancedAKT2",
        "name" : "AKT2_[(T309)]-{p} (directed) enhancedAKT2",
        "interaction" : "AND",
        "SUID" : 1079,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1078",
        "source" : "93",
        "target" : "1022",
        "shared_name" : "AKT2_[(T309)]-{p} (directed) PP2A_p-_AKT2_[(T309)]",
        "name" : "AKT2_[(T309)]-{p} (directed) PP2A_p-_AKT2_[(T309)]",
        "interaction" : "ss",
        "SUID" : 1078,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1077",
        "source" : "92",
        "target" : "93",
        "shared_name" : "PDK1_p+_AKT2_[(T309)] (directed) AKT2_[(T309)]-{p}",
        "name" : "PDK1_p+_AKT2_[(T309)] (directed) AKT2_[(T309)]-{p}",
        "interaction" : "produce",
        "SUID" : 1077,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1076",
        "source" : "91",
        "target" : "89",
        "shared_name" : "AKT2_[PI]_i-_PI_[PH] (directed) AKT2_[PI]--PI_[PH]",
        "name" : "AKT2_[PI]_i-_PI_[PH] (directed) AKT2_[PI]--PI_[PH]",
        "interaction" : "consume",
        "SUID" : 1076,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1075",
        "source" : "90",
        "target" : "88",
        "shared_name" : "PIP3 (directed) AKT2_[PI]_i+_PI_[PH]",
        "name" : "PIP3 (directed) AKT2_[PI]_i+_PI_[PH]",
        "interaction" : "!",
        "SUID" : 1075,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1074",
        "source" : "89",
        "target" : "94",
        "shared_name" : "AKT2_[PI]--PI_[PH] (directed) mTORC2_p+_AKT2_[(S474)]",
        "name" : "AKT2_[PI]--PI_[PH] (directed) mTORC2_p+_AKT2_[(S474)]",
        "interaction" : "!",
        "SUID" : 1074,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1073",
        "source" : "89",
        "target" : "92",
        "shared_name" : "AKT2_[PI]--PI_[PH] (directed) PDK1_p+_AKT2_[(T309)]",
        "name" : "AKT2_[PI]--PI_[PH] (directed) PDK1_p+_AKT2_[(T309)]",
        "interaction" : "!",
        "SUID" : 1073,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1072",
        "source" : "89",
        "target" : "91",
        "shared_name" : "AKT2_[PI]--PI_[PH] (directed) AKT2_[PI]_i-_PI_[PH]",
        "name" : "AKT2_[PI]--PI_[PH] (directed) AKT2_[PI]_i-_PI_[PH]",
        "interaction" : "ss",
        "SUID" : 1072,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1071",
        "source" : "88",
        "target" : "89",
        "shared_name" : "AKT2_[PI]_i+_PI_[PH] (directed) AKT2_[PI]--PI_[PH]",
        "name" : "AKT2_[PI]_i+_PI_[PH] (directed) AKT2_[PI]--PI_[PH]",
        "interaction" : "produce",
        "SUID" : 1071,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1070",
        "source" : "87",
        "target" : "75",
        "shared_name" : "INPP4B_p-_PI_[(4)] (directed) PI_[(4)]-{p}",
        "name" : "INPP4B_p-_PI_[(4)] (directed) PI_[(4)]-{p}",
        "interaction" : "consume",
        "SUID" : 1070,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1069",
        "source" : "86",
        "target" : "77",
        "shared_name" : "PIPP_p-_PI_[(5)] (directed) PI_[(5)]-{p}",
        "name" : "PIPP_p-_PI_[(5)] (directed) PI_[(5)]-{p}",
        "interaction" : "consume",
        "SUID" : 1069,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1068",
        "source" : "85",
        "target" : "82",
        "shared_name" : "PTEN_p-_PI_[(3)] (directed) PI_[(3)]-{p}",
        "name" : "PTEN_p-_PI_[(3)] (directed) PI_[(3)]-{p}",
        "interaction" : "consume",
        "SUID" : 1068,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1067",
        "source" : "84",
        "target" : "90",
        "shared_name" : "PI45 (directed) PIP3",
        "name" : "PI45 (directed) PIP3",
        "interaction" : "AND",
        "SUID" : 1067,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1066",
        "source" : "84",
        "target" : "81",
        "shared_name" : "PI45 (directed) PI3K_p+_PI_[(3)]",
        "name" : "PI45 (directed) PI3K_p+_PI_[(3)]",
        "interaction" : "!",
        "SUID" : 1066,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1065",
        "source" : "83",
        "target" : "81",
        "shared_name" : "[activatedPI3K] (directed) PI3K_p+_PI_[(3)]",
        "name" : "[activatedPI3K] (directed) PI3K_p+_PI_[(3)]",
        "interaction" : "!",
        "SUID" : 1065,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1064",
        "source" : "82",
        "target" : "90",
        "shared_name" : "PI_[(3)]-{p} (directed) PIP3",
        "name" : "PI_[(3)]-{p} (directed) PIP3",
        "interaction" : "AND",
        "SUID" : 1064,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1063",
        "source" : "82",
        "target" : "87",
        "shared_name" : "PI_[(3)]-{p} (directed) INPP4B_p-_PI_[(4)]",
        "name" : "PI_[(3)]-{p} (directed) INPP4B_p-_PI_[(4)]",
        "interaction" : "!",
        "SUID" : 1063,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1062",
        "source" : "82",
        "target" : "86",
        "shared_name" : "PI_[(3)]-{p} (directed) PIPP_p-_PI_[(5)]",
        "name" : "PI_[(3)]-{p} (directed) PIPP_p-_PI_[(5)]",
        "interaction" : "!",
        "SUID" : 1062,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1061",
        "source" : "82",
        "target" : "85",
        "shared_name" : "PI_[(3)]-{p} (directed) PTEN_p-_PI_[(3)]",
        "name" : "PI_[(3)]-{p} (directed) PTEN_p-_PI_[(3)]",
        "interaction" : "ss",
        "SUID" : 1061,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1060",
        "source" : "81",
        "target" : "82",
        "shared_name" : "PI3K_p+_PI_[(3)] (directed) PI_[(3)]-{p}",
        "name" : "PI3K_p+_PI_[(3)] (directed) PI_[(3)]-{p}",
        "interaction" : "produce",
        "SUID" : 1060,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1059",
        "source" : "80",
        "target" : "77",
        "shared_name" : "SYNJ2_p-_PI_[(5)] (directed) PI_[(5)]-{p}",
        "name" : "SYNJ2_p-_PI_[(5)] (directed) PI_[(5)]-{p}",
        "interaction" : "consume",
        "SUID" : 1059,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1058",
        "source" : "79",
        "target" : "75",
        "shared_name" : "SAC1M1L_p-_PI_[(4)] (directed) PI_[(4)]-{p}",
        "name" : "SAC1M1L_p-_PI_[(4)] (directed) PI_[(4)]-{p}",
        "interaction" : "consume",
        "SUID" : 1058,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1057",
        "source" : "78",
        "target" : "84",
        "shared_name" : "PI4 (directed) PI45",
        "name" : "PI4 (directed) PI45",
        "interaction" : "AND",
        "SUID" : 1057,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1056",
        "source" : "78",
        "target" : "80",
        "shared_name" : "PI4 (directed) SYNJ2_p-_PI_[(5)]",
        "name" : "PI4 (directed) SYNJ2_p-_PI_[(5)]",
        "interaction" : "!",
        "SUID" : 1056,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1055",
        "source" : "78",
        "target" : "76",
        "shared_name" : "PI4 (directed) PIPK1alpha_p+_PI_[(5)]",
        "name" : "PI4 (directed) PIPK1alpha_p+_PI_[(5)]",
        "interaction" : "!",
        "SUID" : 1055,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1054",
        "source" : "77",
        "target" : "86",
        "shared_name" : "PI_[(5)]-{p} (directed) PIPP_p-_PI_[(5)]",
        "name" : "PI_[(5)]-{p} (directed) PIPP_p-_PI_[(5)]",
        "interaction" : "ss",
        "SUID" : 1054,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1053",
        "source" : "77",
        "target" : "85",
        "shared_name" : "PI_[(5)]-{p} (directed) PTEN_p-_PI_[(3)]",
        "name" : "PI_[(5)]-{p} (directed) PTEN_p-_PI_[(3)]",
        "interaction" : "!",
        "SUID" : 1053,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1052",
        "source" : "77",
        "target" : "84",
        "shared_name" : "PI_[(5)]-{p} (directed) PI45",
        "name" : "PI_[(5)]-{p} (directed) PI45",
        "interaction" : "AND",
        "SUID" : 1052,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1051",
        "source" : "77",
        "target" : "80",
        "shared_name" : "PI_[(5)]-{p} (directed) SYNJ2_p-_PI_[(5)]",
        "name" : "PI_[(5)]-{p} (directed) SYNJ2_p-_PI_[(5)]",
        "interaction" : "ss",
        "SUID" : 1051,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1050",
        "source" : "76",
        "target" : "77",
        "shared_name" : "PIPK1alpha_p+_PI_[(5)] (directed) PI_[(5)]-{p}",
        "name" : "PIPK1alpha_p+_PI_[(5)] (directed) PI_[(5)]-{p}",
        "interaction" : "produce",
        "SUID" : 1050,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1049",
        "source" : "75",
        "target" : "87",
        "shared_name" : "PI_[(4)]-{p} (directed) INPP4B_p-_PI_[(4)]",
        "name" : "PI_[(4)]-{p} (directed) INPP4B_p-_PI_[(4)]",
        "interaction" : "ss",
        "SUID" : 1049,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1048",
        "source" : "75",
        "target" : "86",
        "shared_name" : "PI_[(4)]-{p} (directed) PIPP_p-_PI_[(5)]",
        "name" : "PI_[(4)]-{p} (directed) PIPP_p-_PI_[(5)]",
        "interaction" : "!",
        "SUID" : 1048,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1047",
        "source" : "75",
        "target" : "85",
        "shared_name" : "PI_[(4)]-{p} (directed) PTEN_p-_PI_[(3)]",
        "name" : "PI_[(4)]-{p} (directed) PTEN_p-_PI_[(3)]",
        "interaction" : "!",
        "SUID" : 1047,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1046",
        "source" : "75",
        "target" : "79",
        "shared_name" : "PI_[(4)]-{p} (directed) SAC1M1L_p-_PI_[(4)]",
        "name" : "PI_[(4)]-{p} (directed) SAC1M1L_p-_PI_[(4)]",
        "interaction" : "ss",
        "SUID" : 1046,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1045",
        "source" : "75",
        "target" : "78",
        "shared_name" : "PI_[(4)]-{p} (directed) PI4",
        "name" : "PI_[(4)]-{p} (directed) PI4",
        "interaction" : "AND",
        "SUID" : 1045,
        "shared_interaction" : "AND",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1044",
        "source" : "74",
        "target" : "75",
        "shared_name" : "PI4K3alpha_p+_PI_[(4)] (directed) PI_[(4)]-{p}",
        "name" : "PI4K3alpha_p+_PI_[(4)] (directed) PI_[(4)]-{p}",
        "interaction" : "produce",
        "SUID" : 1044,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1043",
        "source" : "73",
        "target" : "72",
        "shared_name" : "IRS_[pY]_ppi-_PI3K_[SH2] (directed) IRS_[pY]--PI3K_[SH2]",
        "name" : "IRS_[pY]_ppi-_PI3K_[SH2] (directed) IRS_[pY]--PI3K_[SH2]",
        "interaction" : "consume",
        "SUID" : 1043,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1042",
        "source" : "72",
        "target" : "83",
        "shared_name" : "IRS_[pY]--PI3K_[SH2] (directed) [activatedPI3K]",
        "name" : "IRS_[pY]--PI3K_[SH2] (directed) [activatedPI3K]",
        "interaction" : "!",
        "SUID" : 1042,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1041",
        "source" : "72",
        "target" : "73",
        "shared_name" : "IRS_[pY]--PI3K_[SH2] (directed) IRS_[pY]_ppi-_PI3K_[SH2]",
        "name" : "IRS_[pY]--PI3K_[SH2] (directed) IRS_[pY]_ppi-_PI3K_[SH2]",
        "interaction" : "ss",
        "SUID" : 1041,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1040",
        "source" : "71",
        "target" : "72",
        "shared_name" : "IRS_[pY]_ppi+_PI3K_[SH2] (directed) IRS_[pY]--PI3K_[SH2]",
        "name" : "IRS_[pY]_ppi+_PI3K_[SH2] (directed) IRS_[pY]--PI3K_[SH2]",
        "interaction" : "produce",
        "SUID" : 1040,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1039",
        "source" : "70",
        "target" : "68",
        "shared_name" : "RTK_p-_IRS_[(RTK)] (directed) IRS_[(RTK)]-{p}",
        "name" : "RTK_p-_IRS_[(RTK)] (directed) IRS_[(RTK)]-{p}",
        "interaction" : "consume",
        "SUID" : 1039,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1038",
        "source" : "69",
        "target" : "67",
        "shared_name" : "[activatedEGFR] (directed) RTK_p+_IRS_[(RTK)]",
        "name" : "[activatedEGFR] (directed) RTK_p+_IRS_[(RTK)]",
        "interaction" : "!",
        "SUID" : 1038,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1037",
        "source" : "68",
        "target" : "71",
        "shared_name" : "IRS_[(RTK)]-{p} (directed) IRS_[pY]_ppi+_PI3K_[SH2]",
        "name" : "IRS_[(RTK)]-{p} (directed) IRS_[pY]_ppi+_PI3K_[SH2]",
        "interaction" : "!",
        "SUID" : 1037,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1036",
        "source" : "68",
        "target" : "70",
        "shared_name" : "IRS_[(RTK)]-{p} (directed) RTK_p-_IRS_[(RTK)]",
        "name" : "IRS_[(RTK)]-{p} (directed) RTK_p-_IRS_[(RTK)]",
        "interaction" : "ss",
        "SUID" : 1036,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1035",
        "source" : "67",
        "target" : "68",
        "shared_name" : "RTK_p+_IRS_[(RTK)] (directed) IRS_[(RTK)]-{p}",
        "name" : "RTK_p+_IRS_[(RTK)] (directed) IRS_[(RTK)]-{p}",
        "interaction" : "produce",
        "SUID" : 1035,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1034",
        "source" : "66",
        "target" : "63",
        "shared_name" : "mitogen_[EGFR]_ppi-_EGFR_[mitogen] (directed) EGFR_[mitogen]--mitogen_[EGFR]",
        "name" : "mitogen_[EGFR]_ppi-_EGFR_[mitogen] (directed) EGFR_[mitogen]--mitogen_[EGFR]",
        "interaction" : "consume",
        "SUID" : 1034,
        "shared_interaction" : "consume",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1033",
        "source" : "65",
        "target" : "62",
        "shared_name" : "[mitogen] (directed) mitogen_[EGFR]_ppi+_EGFR_[mitogen]",
        "name" : "[mitogen] (directed) mitogen_[EGFR]_ppi+_EGFR_[mitogen]",
        "interaction" : "!",
        "SUID" : 1033,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1032",
        "source" : "64",
        "target" : "62",
        "shared_name" : "[EGFR] (directed) mitogen_[EGFR]_ppi+_EGFR_[mitogen]",
        "name" : "[EGFR] (directed) mitogen_[EGFR]_ppi+_EGFR_[mitogen]",
        "interaction" : "!",
        "SUID" : 1032,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1031",
        "source" : "63",
        "target" : "69",
        "shared_name" : "EGFR_[mitogen]--mitogen_[EGFR] (directed) [activatedEGFR]",
        "name" : "EGFR_[mitogen]--mitogen_[EGFR] (directed) [activatedEGFR]",
        "interaction" : "!",
        "SUID" : 1031,
        "shared_interaction" : "!",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1030",
        "source" : "63",
        "target" : "66",
        "shared_name" : "EGFR_[mitogen]--mitogen_[EGFR] (directed) mitogen_[EGFR]_ppi-_EGFR_[mitogen]",
        "name" : "EGFR_[mitogen]--mitogen_[EGFR] (directed) mitogen_[EGFR]_ppi-_EGFR_[mitogen]",
        "interaction" : "ss",
        "SUID" : 1030,
        "shared_interaction" : "ss",
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1029",
        "source" : "62",
        "target" : "63",
        "shared_name" : "mitogen_[EGFR]_ppi+_EGFR_[mitogen] (directed) EGFR_[mitogen]--mitogen_[EGFR]",
        "name" : "mitogen_[EGFR]_ppi+_EGFR_[mitogen] (directed) EGFR_[mitogen]--mitogen_[EGFR]",
        "interaction" : "produce",
        "SUID" : 1029,
        "shared_interaction" : "produce",
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}