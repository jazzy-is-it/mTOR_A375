var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.1",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "rxncon2regulatorygraph",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "bold",
      "font-size" : 12,
      "background-color" : "rgb(102,204,255)",
      "height" : 40.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[type = 'output']",
    "css" : {
      "background-color" : "rgb(153,153,153)"
    }
  }, {
    "selector" : "node[type = 'input']",
    "css" : {
      "background-color" : "rgb(153,153,153)"
    }
  }, {
    "selector" : "node[type = 'component']",
    "css" : {
      "background-color" : "rgb(204,255,204)"
    }
  }, {
    "selector" : "node[type = 'reaction']",
    "css" : {
      "background-color" : "rgb(255,204,204)"
    }
  }, {
    "selector" : "node[type = 'boolean']",
    "css" : {
      "background-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "node[type = 'boolean_and']",
    "css" : {
      "background-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "node[type = 'component_state']",
    "css" : {
      "background-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "node[type = 'boolean_not']",
    "css" : {
      "background-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "node[type = 'boolean_or']",
    "css" : {
      "background-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "node[type = 'state']",
    "css" : {
      "background-color" : "rgb(204,204,255)"
    }
  }, {
    "selector" : "node[type = 'boolean']",
    "css" : {
      "width" : 35.0,
      "height" : 35.0
    }
  }, {
    "selector" : "node[type = 'boolean_not']",
    "css" : {
      "width" : 30.0,
      "height" : 30.0
    }
  }, {
    "selector" : "node[type = 'boolean']",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[type = 'boolean_and']",
    "css" : {
      "shape" : "triangle"
    }
  }, {
    "selector" : "node[type = 'boolean_not']",
    "css" : {
      "shape" : "octagon"
    }
  }, {
    "selector" : "node[type = 'boolean_or']",
    "css" : {
      "shape" : "diamond"
    }
  }, {
    "selector" : "node[ id = '62' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "mitogen_[EGFR]_ppi+_EGFR_[mitogen]"
    }
  }, {
    "selector" : "node[ id = '63' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "EGFR_[mitogen]--mitogen_[EGFR]"
    }
  }, {
    "selector" : "node[ id = '64' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(153,153,153)",
      "height" : 40.0,
      "content" : "[EGFR]"
    }
  }, {
    "selector" : "node[ id = '65' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(153,153,153)",
      "height" : 40.0,
      "content" : "[mitogen]"
    }
  }, {
    "selector" : "node[ id = '66' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "mitogen_[EGFR]_ppi-_EGFR_[mitogen]"
    }
  }, {
    "selector" : "node[ id = '67' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "RTK_p+_IRS_[(RTK)]"
    }
  }, {
    "selector" : "node[ id = '68' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "IRS_[(RTK)]-{p}"
    }
  }, {
    "selector" : "node[ id = '69' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(153,153,153)",
      "height" : 40.0,
      "content" : "[activatedEGFR]"
    }
  }, {
    "selector" : "node[ id = '70' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "RTK_p-_IRS_[(RTK)]"
    }
  }, {
    "selector" : "node[ id = '582' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "RHEB_[switch1DSYDPTIEN]_ppi-_mTOR_[FATfα2fα3]"
    }
  }, {
    "selector" : "node[ id = '71' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "IRS_[pY]_ppi+_PI3K_[SH2]"
    }
  }, {
    "selector" : "node[ id = '583' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "RHEB_[switch1DSYDPTIEN]--mTOR_[FATfα2fα3]"
    }
  }, {
    "selector" : "node[ id = '72' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "IRS_[pY]--PI3K_[SH2]"
    }
  }, {
    "selector" : "node[ id = '584' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "RHEB_[switch1DSYDPTIEN]_ppi+_mTOR_[FATfα2fα3]"
    }
  }, {
    "selector" : "node[ id = '73' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "IRS_[pY]_ppi-_PI3K_[SH2]"
    }
  }, {
    "selector" : "node[ id = '585' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi-_mTOR_[Nheatnα3tonα7]"
    }
  }, {
    "selector" : "node[ id = '74' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "PI4K3alpha_p+_PI_[(4)]"
    }
  }, {
    "selector" : "node[ id = '586' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]--mTOR_[Nheatnα3tonα7]"
    }
  }, {
    "selector" : "node[ id = '75' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "PI_[(4)]-{p}"
    }
  }, {
    "selector" : "node[ id = '587' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "RHEB_[switch2GQDEYSIFPQTYSIDIN]_ppi+_mTOR_[Nheatnα3tonα7]"
    }
  }, {
    "selector" : "node[ id = '76' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "PIPK1alpha_p+_PI_[(5)]"
    }
  }, {
    "selector" : "node[ id = '588' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "RHEB_[switch1]_ppi-_mTOR_[Mheatmα2mα3mα4]"
    }
  }, {
    "selector" : "node[ id = '77' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "PI_[(5)]-{p}"
    }
  }, {
    "selector" : "node[ id = '589' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "RHEB_[switch1]--mTOR_[Mheatmα2mα3mα4]"
    }
  }, {
    "selector" : "node[ id = '78' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "triangle",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,255,255)",
      "height" : 40.0,
      "content" : "PI4"
    }
  }, {
    "selector" : "node[ id = '590' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "RHEB_[switch1]_ppi+_mTOR_[Mheatmα2mα3mα4]"
    }
  }, {
    "selector" : "node[ id = '79' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "SAC1M1L_p-_PI_[(4)]"
    }
  }, {
    "selector" : "node[ id = '591' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "nk_p-_TSC2_[(Ser1130)]"
    }
  }, {
    "selector" : "node[ id = '80' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "SYNJ2_p-_PI_[(5)]"
    }
  }, {
    "selector" : "node[ id = '592' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "nk_p-_TSC2_[(Ser981)]"
    }
  }, {
    "selector" : "node[ id = '81' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "PI3K_p+_PI_[(3)]"
    }
  }, {
    "selector" : "node[ id = '593' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "nk_p-_TSC2_[(Thr1462)]"
    }
  }, {
    "selector" : "node[ id = '82' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "PI_[(3)]-{p}"
    }
  }, {
    "selector" : "node[ id = '594' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "nk_p-_TSC2_[(Ser939)]"
    }
  }, {
    "selector" : "node[ id = '83' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(153,153,153)",
      "height" : 40.0,
      "content" : "[activatedPI3K]"
    }
  }, {
    "selector" : "node[ id = '595' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "un_p-_PPM1G_[(AKT2)]"
    }
  }, {
    "selector" : "node[ id = '84' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "triangle",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,255,255)",
      "height" : 40.0,
      "content" : "PI45"
    }
  }, {
    "selector" : "node[ id = '596' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "nn_p-_AKT2_[(S474)]"
    }
  }, {
    "selector" : "node[ id = '85' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "PTEN_p-_PI_[(3)]"
    }
  }, {
    "selector" : "node[ id = '597' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "nn_p-_AKT2_[(T309)]"
    }
  }, {
    "selector" : "node[ id = '86' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "PIPP_p-_PI_[(5)]"
    }
  }, {
    "selector" : "node[ id = '87' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "INPP4B_p-_PI_[(4)]"
    }
  }, {
    "selector" : "node[ id = '88' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "AKT2_[PI]_i+_PI_[PH]"
    }
  }, {
    "selector" : "node[ id = '89' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "AKT2_[PI]--PI_[PH]"
    }
  }, {
    "selector" : "node[ id = '90' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "triangle",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,255,255)",
      "height" : 40.0,
      "content" : "PIP3"
    }
  }, {
    "selector" : "node[ id = '91' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "AKT2_[PI]_i-_PI_[PH]"
    }
  }, {
    "selector" : "node[ id = '92' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "PDK1_p+_AKT2_[(T309)]"
    }
  }, {
    "selector" : "node[ id = '93' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "AKT2_[(T309)]-{p}"
    }
  }, {
    "selector" : "node[ id = '94' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "mTORC2_p+_AKT2_[(S474)]"
    }
  }, {
    "selector" : "node[ id = '95' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "AKT2_[(S474)]-{p}"
    }
  }, {
    "selector" : "node[ id = '98' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "AKT2_p+_TSC2_[(Ser939)]"
    }
  }, {
    "selector" : "node[ id = '99' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "TSC2_[(Ser939)]-{p}"
    }
  }, {
    "selector" : "node[ id = '100' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "triangle",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,255,255)",
      "height" : 40.0,
      "content" : "enhancedAKT2"
    }
  }, {
    "selector" : "node[ id = '101' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "AKT2_p+_TSC2_[(Thr1462)]"
    }
  }, {
    "selector" : "node[ id = '102' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "TSC2_[(Thr1462)]-{p}"
    }
  }, {
    "selector" : "node[ id = '103' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "AKT2_p+_TSC2_[(Ser981)]"
    }
  }, {
    "selector" : "node[ id = '104' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "TSC2_[(Ser981)]-{p}"
    }
  }, {
    "selector" : "node[ id = '105' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "AKT2_p+_TSC2_[(Ser1130)]"
    }
  }, {
    "selector" : "node[ id = '106' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "TSC2_[(Ser1130)]-{p}"
    }
  }, {
    "selector" : "node[ id = '107' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "AKT2_p+_PPM1G_[(AKT2)]"
    }
  }, {
    "selector" : "node[ id = '108' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "PPM1G_[(AKT2)]-{p}"
    }
  }, {
    "selector" : "node[ id = '114' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "TSC1_[Cterminus]_ppi+_TSC2_[Nterminus]"
    }
  }, {
    "selector" : "node[ id = '115' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "TSC1_[Cterminus]--TSC2_[Nterminus]"
    }
  }, {
    "selector" : "node[ id = '116' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "triangle",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,255,255)",
      "height" : 40.0,
      "content" : "destabilization"
    }
  }, {
    "selector" : "node[ id = '117' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "TSC1_[Cterminus]_ppi-_TSC2_[Nterminus]"
    }
  }, {
    "selector" : "node[ id = '118' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "GTP_gef_RHEB_[(G)]"
    }
  }, {
    "selector" : "node[ id = '119' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "RHEB_[(G)]-{gtp}"
    }
  }, {
    "selector" : "node[ id = '120' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "TSC2_gap_RHEB_[(G)]"
    }
  }, {
    "selector" : "node[ id = '130' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "mTOR_[Raptor]_ppi+_Raptor_[mTOR]"
    }
  }, {
    "selector" : "node[ id = '131' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "Raptor_[mTOR]--mTOR_[Raptor]"
    }
  }, {
    "selector" : "node[ id = '132' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(153,153,153)",
      "height" : 40.0,
      "content" : "[Raptor]"
    }
  }, {
    "selector" : "node[ id = '133' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(153,153,153)",
      "height" : 40.0,
      "content" : "[mTOR]"
    }
  }, {
    "selector" : "node[ id = '134' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "eIF4E_[A001]_ppi+_EIF4EBP1_[A001]"
    }
  }, {
    "selector" : "node[ id = '135' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "EIF4EBP1_[A001]--eIF4E_[A001]"
    }
  }, {
    "selector" : "node[ id = '136' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(153,153,153)",
      "height" : 40.0,
      "content" : "[EIF4EBP1]"
    }
  }, {
    "selector" : "node[ id = '137' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(153,153,153)",
      "height" : 40.0,
      "content" : "[eIF4E]"
    }
  }, {
    "selector" : "node[ id = '138' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "triangle",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,255,255)",
      "height" : 40.0,
      "content" : "translation"
    }
  }, {
    "selector" : "node[ id = '139' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "EIF4EBP1_[(Thr46)]-{p}"
    }
  }, {
    "selector" : "node[ id = '140' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "EIF4EBP1_[(Thr37)]-{p}"
    }
  }, {
    "selector" : "node[ id = '141' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "EIF4EBP1_[(Ser65)]-{p}"
    }
  }, {
    "selector" : "node[ id = '142' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "EIF4EBP1_[(Thr70)]-{p}"
    }
  }, {
    "selector" : "node[ id = '143' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "eIF4E_[A001]_ppi-_EIF4EBP1_[A001]"
    }
  }, {
    "selector" : "node[ id = '144' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "mTORC1_p+_EIF4EBP1_[(Thr37)]"
    }
  }, {
    "selector" : "node[ id = '145' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "triangle",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,255,255)",
      "height" : 40.0,
      "content" : "mTORC1"
    }
  }, {
    "selector" : "node[ id = '146' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "mTORC1_p+_EIF4EBP1_[(Thr46)]"
    }
  }, {
    "selector" : "node[ id = '147' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "mTORC1_p+_EIF4EBP1_[(Ser65)]"
    }
  }, {
    "selector" : "node[ id = '148' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "mTORC1_p+_EIF4EBP1_[(Thr70)]"
    }
  }, {
    "selector" : "node[ id = '149' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "PPM1G_p-_EIF4EBP1_[(Thr37)]"
    }
  }, {
    "selector" : "node[ id = '150' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "PPM1G_p-_EIF4EBP1_[(Thr46)]"
    }
  }, {
    "selector" : "node[ id = '151' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "PPM1G_p-_EIF4EBP1_[(Ser65)]"
    }
  }, {
    "selector" : "node[ id = '152' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "PPM1G_p-_EIF4EBP1_[(Thr70)]"
    }
  }, {
    "selector" : "node[ id = '153' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "eIF4E_[A001]_ppi+_eIF4G_[A002]"
    }
  }, {
    "selector" : "node[ id = '154' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(204,204,255)",
      "height" : 40.0,
      "content" : "eIF4E_[A001]--eIF4G_[A002]"
    }
  }, {
    "selector" : "node[ id = '155' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(153,153,153)",
      "height" : 40.0,
      "content" : "[eIF4G]"
    }
  }, {
    "selector" : "node[ id = '156' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(255,204,204)",
      "height" : 40.0,
      "content" : "eIF4E_[A001]_ppi-_eIF4G_[A002]"
    }
  }, {
    "selector" : "node[ id = '157' ]",
    "css" : {
      "background-opacity" : 1.0,
      "border-width" : 1.5,
      "text-opacity" : 1.0,
      "shape" : "ellipse",
      "background-color" : "rgb(255,255,0)",
      "border-color" : "rgb(102,102,102)",
      "width" : 40.0,
      "color" : "rgb(0,0,0)",
      "border-opacity" : 1.0,
      "text-valign" : "center",
      "font-family" : "SansSerif",
      "font-weight" : "normal",
      "font-size" : 12,
      "background-color" : "rgb(153,153,153)",
      "height" : 40.0,
      "content" : "[Output]"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(153,153,153)",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge[interaction = 'K+']",
    "css" : {
      "target-arrow-color" : "rgb(0,204,0)"
    }
  }, {
    "selector" : "edge[interaction = 'ss']",
    "css" : {
      "target-arrow-color" : "rgb(204,204,204)"
    }
  }, {
    "selector" : "edge[interaction = 'k+']",
    "css" : {
      "target-arrow-color" : "rgb(0,204,0)"
    }
  }, {
    "selector" : "edge[interaction = 'synthesis']",
    "css" : {
      "target-arrow-color" : "rgb(0,0,0)"
    }
  }, {
    "selector" : "edge[interaction = '!']",
    "css" : {
      "target-arrow-color" : "rgb(0,204,0)"
    }
  }, {
    "selector" : "edge[interaction = 'K-']",
    "css" : {
      "target-arrow-color" : "rgb(255,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'k-']",
    "css" : {
      "target-arrow-color" : "rgb(255,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'OR']",
    "css" : {
      "target-arrow-color" : "rgb(0,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'ps']",
    "css" : {
      "target-arrow-color" : "rgb(204,204,204)"
    }
  }, {
    "selector" : "edge[interaction = 'x ']",
    "css" : {
      "target-arrow-color" : "rgb(255,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'consume']",
    "css" : {
      "target-arrow-color" : "rgb(255,0,255)"
    }
  }, {
    "selector" : "edge[interaction = 'is']",
    "css" : {
      "target-arrow-color" : "rgb(204,204,204)"
    }
  }, {
    "selector" : "edge[interaction = 'produce']",
    "css" : {
      "target-arrow-color" : "rgb(0,0,255)"
    }
  }, {
    "selector" : "edge[interaction = '0']",
    "css" : {
      "target-arrow-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "edge[interaction = 'component']",
    "css" : {
      "target-arrow-color" : "rgb(204,204,204)"
    }
  }, {
    "selector" : "edge[interaction = 'NOT']",
    "css" : {
      "target-arrow-color" : "rgb(0,0,0)"
    }
  }, {
    "selector" : "edge[interaction = '[!]']",
    "css" : {
      "target-arrow-color" : "rgb(0,204,0)"
    }
  }, {
    "selector" : "edge[interaction = 'AND']",
    "css" : {
      "target-arrow-color" : "rgb(0,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'x']",
    "css" : {
      "target-arrow-color" : "rgb(255,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'degrade']",
    "css" : {
      "target-arrow-color" : "rgb(0,0,0)"
    }
  }, {
    "selector" : "edge[interaction = '[!]']",
    "css" : {
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[interaction = 'K-']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'mutually_exclusive']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'k-']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'ps']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'x ']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'x']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'consume']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'degrade']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'mutually_exclusive']",
    "css" : {
      "opacity" : 0.12941176470588237
    }
  }, {
    "selector" : "edge[interaction = 'K+']",
    "css" : {
      "line-color" : "rgb(0,204,0)",
      "target-arrow-color" : "rgb(0,204,0)",
      "source-arrow-color" : "rgb(0,204,0)"
    }
  }, {
    "selector" : "edge[interaction = '0']",
    "css" : {
      "line-color" : "rgb(255,255,255)",
      "target-arrow-color" : "rgb(255,255,255)",
      "source-arrow-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "edge[interaction = '!']",
    "css" : {
      "line-color" : "rgb(0,204,0)",
      "target-arrow-color" : "rgb(0,204,0)",
      "source-arrow-color" : "rgb(0,204,0)"
    }
  }, {
    "selector" : "edge[interaction = 'K-']",
    "css" : {
      "line-color" : "rgb(255,0,0)",
      "target-arrow-color" : "rgb(255,0,0)",
      "source-arrow-color" : "rgb(255,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'OR']",
    "css" : {
      "line-color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-color" : "rgb(0,0,0)"
    }
  }, {
    "selector" : "edge[interaction = '[!]']",
    "css" : {
      "line-color" : "rgb(0,204,0)",
      "target-arrow-color" : "rgb(0,204,0)",
      "source-arrow-color" : "rgb(0,204,0)"
    }
  }, {
    "selector" : "edge[interaction = 'AND']",
    "css" : {
      "line-color" : "rgb(0,0,0)",
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-color" : "rgb(0,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'x ']",
    "css" : {
      "line-color" : "rgb(255,0,0)",
      "target-arrow-color" : "rgb(255,0,0)",
      "source-arrow-color" : "rgb(255,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'x']",
    "css" : {
      "line-color" : "rgb(255,0,0)",
      "target-arrow-color" : "rgb(255,0,0)",
      "source-arrow-color" : "rgb(255,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'consume']",
    "css" : {
      "line-color" : "rgb(255,0,255)",
      "target-arrow-color" : "rgb(255,0,255)",
      "source-arrow-color" : "rgb(255,0,255)"
    }
  }, {
    "selector" : "edge[interaction = 'produce']",
    "css" : {
      "line-color" : "rgb(0,0,255)",
      "target-arrow-color" : "rgb(0,0,255)",
      "source-arrow-color" : "rgb(0,0,255)"
    }
  }, {
    "selector" : "edge[interaction = 'K+']",
    "css" : {
      "line-color" : "rgb(0,204,0)"
    }
  }, {
    "selector" : "edge[interaction = 'ss']",
    "css" : {
      "line-color" : "rgb(204,204,204)"
    }
  }, {
    "selector" : "edge[interaction = 'synthesis']",
    "css" : {
      "line-color" : "rgb(0,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'k+']",
    "css" : {
      "line-color" : "rgb(0,204,0)"
    }
  }, {
    "selector" : "edge[interaction = '!']",
    "css" : {
      "line-color" : "rgb(0,204,0)"
    }
  }, {
    "selector" : "edge[interaction = 'K-']",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'k-']",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'OR']",
    "css" : {
      "line-color" : "rgb(0,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'ps']",
    "css" : {
      "line-color" : "rgb(204,204,204)"
    }
  }, {
    "selector" : "edge[interaction = 'x ']",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'consume']",
    "css" : {
      "line-color" : "rgb(255,0,255)"
    }
  }, {
    "selector" : "edge[interaction = 'is']",
    "css" : {
      "line-color" : "rgb(204,204,204)"
    }
  }, {
    "selector" : "edge[interaction = 'produce']",
    "css" : {
      "line-color" : "rgb(0,0,255)"
    }
  }, {
    "selector" : "edge[interaction = '0']",
    "css" : {
      "line-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "edge[interaction = 'component']",
    "css" : {
      "line-color" : "rgb(204,204,204)"
    }
  }, {
    "selector" : "edge[interaction = 'NOT']",
    "css" : {
      "line-color" : "rgb(0,0,0)"
    }
  }, {
    "selector" : "edge[interaction = '[!]']",
    "css" : {
      "line-color" : "rgb(0,204,0)"
    }
  }, {
    "selector" : "edge[interaction = 'AND']",
    "css" : {
      "line-color" : "rgb(0,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'x']",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'degrade']",
    "css" : {
      "line-color" : "rgb(0,0,0)"
    }
  }, {
    "selector" : "edge[ id = '751' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '752' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '753' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '754' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '755' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '598' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '599' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '600' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '601' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '602' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '603' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '604' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '605' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '606' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '607' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '608' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '609' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '610' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '611' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '612' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '613' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '614' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '615' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '616' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '617' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '618' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '619' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '620' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '621' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '622' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '623' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '624' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '625' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '626' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '627' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '628' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '629' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '630' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '631' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "x",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '632' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '633' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '634' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '635' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "x",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '636' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '637' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '638' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '639' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '640' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '641' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '642' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '643' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '644' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '645' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '646' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '647' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '648' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '649' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '650' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '651' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '652' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '653' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '654' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '655' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '656' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '657' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '658' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '659' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '660' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '661' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '662' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '663' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '664' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '665' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '666' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '667' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "x",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '668' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '669' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '670' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '671' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '672' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '673' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '674' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '675' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '676' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "x",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '677' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "x",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '678' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "x",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '679' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "x",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '680' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '681' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '682' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '683' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '684' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '685' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '686' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '687' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '688' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '689' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '690' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '691' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "x",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '692' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '693' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '694' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '695' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '696' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '697' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '698' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '699' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '700' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '701' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '702' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '703' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '704' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '705' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '706' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '707' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '708' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '709' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '710' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '711' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '712' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '713' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '714' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '715' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '716' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '717' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '718' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '719' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '720' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '721' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '722' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '723' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '724' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '725' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '726' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '727' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '728' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '729' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '730' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '731' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '732' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '733' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '734' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '735' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '736' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '737' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '738' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '739' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "AND",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '740' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '741' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '742' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '743' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '744' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '745' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '746' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '747' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,204,0)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,204,0)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "!",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '748' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(204,204,204)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(204,204,204)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "ss",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '749' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(0,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(0,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "produce",
      "target-arrow-shape" : "triangle",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge[ id = '750' ]",
    "css" : {
      "font-size" : 10,
      "target-arrow-color" : "rgb(255,0,255)",
      "font-family" : "Dialog",
      "font-weight" : "normal",
      "line-style" : "solid",
      "width" : 1.5,
      "line-color" : "rgb(255,0,255)",
      "color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "source-arrow-color" : "rgb(0,0,0)",
      "content" : "consume",
      "target-arrow-shape" : "tee",
      "opacity" : 1.0,
      "text-opacity" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]